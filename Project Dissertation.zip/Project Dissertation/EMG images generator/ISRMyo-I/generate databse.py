import numpy as np
import h5py



"""

    train set for six persons.

"""



train_bangli_label = open('/Users/micheng/PycharmProjects/dissertation_project/ISRMyo-I-master/emgData/train_bangli/y.txt',
               'r')
train_bangli_1 = open('/Users/micheng/PycharmProjects/dissertation_project/ISRMyo-I-master/emgData/train_bangli/C01_train.txt',
               'r')
train_bangli_2 = open('/Users/micheng/PycharmProjects/dissertation_project/ISRMyo-I-master/emgData/train_bangli/C02_train.txt',
               'r')
train_bangli_3 = open('/Users/micheng/PycharmProjects/dissertation_project/ISRMyo-I-master/emgData/train_bangli/C03_train.txt',
               'r')
train_bangli_4 = open('/Users/micheng/PycharmProjects/dissertation_project/ISRMyo-I-master/emgData/train_bangli/C04_train.txt',
               'r')
train_bangli_5 = open('/Users/micheng/PycharmProjects/dissertation_project/ISRMyo-I-master/emgData/train_bangli/C05_train.txt',
               'r')
train_bangli_6 = open('/Users/micheng/PycharmProjects/dissertation_project/ISRMyo-I-master/emgData/train_bangli/C06_train.txt',
               'r')
train_bangli_7 = open('/Users/micheng/PycharmProjects/dissertation_project/ISRMyo-I-master/emgData/train_bangli/C07_train.txt',
               'r')
train_bangli_8 = open('/Users/micheng/PycharmProjects/dissertation_project/ISRMyo-I-master/emgData/train_bangli/C08_train.txt',
               'r')
train_bangli_9 = open('/Users/micheng/PycharmProjects/dissertation_project/ISRMyo-I-master/emgData/train_bangli/C09_train.txt',
               'r')
train_bangli_10 = open('/Users/micheng/PycharmProjects/dissertation_project/ISRMyo-I-master/emgData/train_bangli/C10_train.txt',
               'r')
train_bangli_11 = open('/Users/micheng/PycharmProjects/dissertation_project/ISRMyo-I-master/emgData/train_bangli/C11_train.txt',
               'r')
train_bangli_12 = open('/Users/micheng/PycharmProjects/dissertation_project/ISRMyo-I-master/emgData/train_bangli/C12_train.txt',
               'r')
train_bangli_13 = open('/Users/micheng/PycharmProjects/dissertation_project/ISRMyo-I-master/emgData/train_bangli/C13_train.txt',
               'r')
train_bangli_14 = open('/Users/micheng/PycharmProjects/dissertation_project/ISRMyo-I-master/emgData/train_bangli/C14_train.txt',
               'r')
train_bangli_15 = open('/Users/micheng/PycharmProjects/dissertation_project/ISRMyo-I-master/emgData/train_bangli/C15_train.txt',
               'r')
train_bangli_16 = open('/Users/micheng/PycharmProjects/dissertation_project/ISRMyo-I-master/emgData/train_bangli/C16_train.txt',
               'r')


train_name = [train_bangli_label, train_bangli_1, train_bangli_2, train_bangli_3, train_bangli_4, train_bangli_5,
              train_bangli_6, train_bangli_7, train_bangli_8, train_bangli_9, train_bangli_10, train_bangli_11,
              train_bangli_12, train_bangli_13, train_bangli_14, train_bangli_15, train_bangli_16]

train_bangli_list = [[] for i in range(13650)]

for index, lines in enumerate(train_name):
    x = 0
    for line in lines.readlines():
        # print(line)
        train_bangli_list[x].extend([float(i) for i in line.split()])
        x += 1

    lines.close()

train_bangli = np.array(train_bangli_list)
print(train_bangli)
print(type(train_bangli), train_bangli.shape, train_bangli.size)




# ----------------------------------------------------------------------------------------------------------------------------------------------




train_disi_label = open('/Users/micheng/PycharmProjects/dissertation_project/ISRMyo-I-master/emgData/train_disi/y.txt',
               'r')
train_disi_1 = open('/Users/micheng/PycharmProjects/dissertation_project/ISRMyo-I-master/emgData/train_disi/C01_train.txt',
               'r')
train_disi_2 = open('/Users/micheng/PycharmProjects/dissertation_project/ISRMyo-I-master/emgData/train_disi/C02_train.txt',
               'r')
train_disi_3 = open('/Users/micheng/PycharmProjects/dissertation_project/ISRMyo-I-master/emgData/train_disi/C03_train.txt',
               'r')
train_disi_4 = open('/Users/micheng/PycharmProjects/dissertation_project/ISRMyo-I-master/emgData/train_disi/C04_train.txt',
               'r')
train_disi_5 = open('/Users/micheng/PycharmProjects/dissertation_project/ISRMyo-I-master/emgData/train_disi/C05_train.txt',
               'r')
train_disi_6 = open('/Users/micheng/PycharmProjects/dissertation_project/ISRMyo-I-master/emgData/train_disi/C06_train.txt',
               'r')
train_disi_7 = open('/Users/micheng/PycharmProjects/dissertation_project/ISRMyo-I-master/emgData/train_disi/C07_train.txt',
               'r')
train_disi_8 = open('/Users/micheng/PycharmProjects/dissertation_project/ISRMyo-I-master/emgData/train_disi/C08_train.txt',
               'r')
train_disi_9 = open('/Users/micheng/PycharmProjects/dissertation_project/ISRMyo-I-master/emgData/train_disi/C09_train.txt',
               'r')
train_disi_10 = open('/Users/micheng/PycharmProjects/dissertation_project/ISRMyo-I-master/emgData/train_disi/C10_train.txt',
               'r')
train_disi_11 = open('/Users/micheng/PycharmProjects/dissertation_project/ISRMyo-I-master/emgData/train_disi/C11_train.txt',
               'r')
train_disi_12 = open('/Users/micheng/PycharmProjects/dissertation_project/ISRMyo-I-master/emgData/train_disi/C12_train.txt',
               'r')
train_disi_13 = open('/Users/micheng/PycharmProjects/dissertation_project/ISRMyo-I-master/emgData/train_disi/C13_train.txt',
               'r')
train_disi_14 = open('/Users/micheng/PycharmProjects/dissertation_project/ISRMyo-I-master/emgData/train_disi/C14_train.txt',
               'r')
train_disi_15 = open('/Users/micheng/PycharmProjects/dissertation_project/ISRMyo-I-master/emgData/train_disi/C15_train.txt',
               'r')
train_disi_16 = open('/Users/micheng/PycharmProjects/dissertation_project/ISRMyo-I-master/emgData/train_disi/C16_train.txt',
               'r')

train_name = [train_disi_label, train_disi_1, train_disi_2, train_disi_3, train_disi_4, train_disi_5,
              train_disi_6, train_disi_7, train_disi_8, train_disi_9, train_disi_10, train_disi_11,
              train_disi_12, train_disi_13, train_disi_14, train_disi_15, train_disi_16]

train_disi_list = [[] for i in range(13650)]

for index, lines in enumerate(train_name):
    x = 0
    for line in lines.readlines():
        # print(line)
        train_disi_list[x].extend([float(i) for i in line.split()])
        x += 1

    lines.close()

train_disi = np.array(train_disi_list)
print(train_disi)
print(type(train_disi), train_disi.shape, train_disi.size)




# ----------------------------------------------------------------------------------------------------------------------------------------------




train_kairu_label = open('/Users/micheng/PycharmProjects/dissertation_project/ISRMyo-I-master/emgData/train_kairu/y.txt',
               'r')
train_kairu_1 = open('/Users/micheng/PycharmProjects/dissertation_project/ISRMyo-I-master/emgData/train_kairu/C01_train.txt',
               'r')
train_kairu_2 = open('/Users/micheng/PycharmProjects/dissertation_project/ISRMyo-I-master/emgData/train_kairu/C02_train.txt',
               'r')
train_kairu_3 = open('/Users/micheng/PycharmProjects/dissertation_project/ISRMyo-I-master/emgData/train_kairu/C03_train.txt',
               'r')
train_kairu_4 = open('/Users/micheng/PycharmProjects/dissertation_project/ISRMyo-I-master/emgData/train_kairu/C04_train.txt',
               'r')
train_kairu_5 = open('/Users/micheng/PycharmProjects/dissertation_project/ISRMyo-I-master/emgData/train_kairu/C05_train.txt',
               'r')
train_kairu_6 = open('/Users/micheng/PycharmProjects/dissertation_project/ISRMyo-I-master/emgData/train_kairu/C06_train.txt',
               'r')
train_kairu_7 = open('/Users/micheng/PycharmProjects/dissertation_project/ISRMyo-I-master/emgData/train_kairu/C07_train.txt',
               'r')
train_kairu_8 = open('/Users/micheng/PycharmProjects/dissertation_project/ISRMyo-I-master/emgData/train_kairu/C08_train.txt',
               'r')
train_kairu_9 = open('/Users/micheng/PycharmProjects/dissertation_project/ISRMyo-I-master/emgData/train_kairu/C09_train.txt',
               'r')
train_kairu_10 = open('/Users/micheng/PycharmProjects/dissertation_project/ISRMyo-I-master/emgData/train_kairu/C10_train.txt',
               'r')
train_kairu_11 = open('/Users/micheng/PycharmProjects/dissertation_project/ISRMyo-I-master/emgData/train_kairu/C11_train.txt',
               'r')
train_kairu_12 = open('/Users/micheng/PycharmProjects/dissertation_project/ISRMyo-I-master/emgData/train_kairu/C12_train.txt',
               'r')
train_kairu_13 = open('/Users/micheng/PycharmProjects/dissertation_project/ISRMyo-I-master/emgData/train_kairu/C13_train.txt',
               'r')
train_kairu_14 = open('/Users/micheng/PycharmProjects/dissertation_project/ISRMyo-I-master/emgData/train_kairu/C14_train.txt',
               'r')
train_kairu_15 = open('/Users/micheng/PycharmProjects/dissertation_project/ISRMyo-I-master/emgData/train_kairu/C15_train.txt',
               'r')
train_kairu_16 = open('/Users/micheng/PycharmProjects/dissertation_project/ISRMyo-I-master/emgData/train_kairu/C16_train.txt',
               'r')

train_name = [train_kairu_label, train_kairu_1, train_kairu_2, train_kairu_3, train_kairu_4, train_kairu_5,
              train_kairu_6, train_kairu_7, train_kairu_8, train_kairu_9, train_kairu_10, train_kairu_11,
              train_kairu_12, train_kairu_13, train_kairu_14, train_kairu_15, train_kairu_16]

train_kairu_list = [[] for i in range(13650)]

for index, lines in enumerate(train_name):
    x = 0
    for line in lines.readlines():
        # print(line)
        train_kairu_list[x].extend([float(i) for i in line.split()])
        x += 1

    lines.close()

train_kairu = np.array(train_kairu_list)
print(train_kairu)
print(type(train_kairu), train_kairu.shape, train_kairu.size)




# ----------------------------------------------------------------------------------------------------------------------------------------------




train_yajie_label = open('/Users/micheng/PycharmProjects/dissertation_project/ISRMyo-I-master/emgData/train_yajie/y.txt',
               'r')
train_yajie_1 = open('/Users/micheng/PycharmProjects/dissertation_project/ISRMyo-I-master/emgData/train_yajie/C01_train.txt',
               'r')
train_yajie_2 = open('/Users/micheng/PycharmProjects/dissertation_project/ISRMyo-I-master/emgData/train_yajie/C02_train.txt',
               'r')
train_yajie_3 = open('/Users/micheng/PycharmProjects/dissertation_project/ISRMyo-I-master/emgData/train_yajie/C03_train.txt',
               'r')
train_yajie_4 = open('/Users/micheng/PycharmProjects/dissertation_project/ISRMyo-I-master/emgData/train_yajie/C04_train.txt',
               'r')
train_yajie_5 = open('/Users/micheng/PycharmProjects/dissertation_project/ISRMyo-I-master/emgData/train_yajie/C05_train.txt',
               'r')
train_yajie_6 = open('/Users/micheng/PycharmProjects/dissertation_project/ISRMyo-I-master/emgData/train_yajie/C06_train.txt',
               'r')
train_yajie_7 = open('/Users/micheng/PycharmProjects/dissertation_project/ISRMyo-I-master/emgData/train_yajie/C07_train.txt',
               'r')
train_yajie_8 = open('/Users/micheng/PycharmProjects/dissertation_project/ISRMyo-I-master/emgData/train_yajie/C08_train.txt',
               'r')
train_yajie_9 = open('/Users/micheng/PycharmProjects/dissertation_project/ISRMyo-I-master/emgData/train_yajie/C09_train.txt',
               'r')
train_yajie_10 = open('/Users/micheng/PycharmProjects/dissertation_project/ISRMyo-I-master/emgData/train_yajie/C10_train.txt',
               'r')
train_yajie_11 = open('/Users/micheng/PycharmProjects/dissertation_project/ISRMyo-I-master/emgData/train_yajie/C11_train.txt',
               'r')
train_yajie_12 = open('/Users/micheng/PycharmProjects/dissertation_project/ISRMyo-I-master/emgData/train_yajie/C12_train.txt',
               'r')
train_yajie_13 = open('/Users/micheng/PycharmProjects/dissertation_project/ISRMyo-I-master/emgData/train_yajie/C13_train.txt',
               'r')
train_yajie_14 = open('/Users/micheng/PycharmProjects/dissertation_project/ISRMyo-I-master/emgData/train_yajie/C14_train.txt',
               'r')
train_yajie_15 = open('/Users/micheng/PycharmProjects/dissertation_project/ISRMyo-I-master/emgData/train_yajie/C15_train.txt',
               'r')
train_yajie_16 = open('/Users/micheng/PycharmProjects/dissertation_project/ISRMyo-I-master/emgData/train_yajie/C16_train.txt',
               'r')

train_name = [train_yajie_label, train_yajie_1, train_yajie_2, train_yajie_3, train_yajie_4, train_yajie_5,
              train_yajie_6, train_yajie_7, train_yajie_8, train_yajie_9, train_yajie_10, train_yajie_11,
              train_yajie_12, train_yajie_13, train_yajie_14, train_yajie_15, train_yajie_16]

train_yajie_list = [[] for i in range(13650)]

for index, lines in enumerate(train_name):
    x = 0
    for line in lines.readlines():
        # print(line)
        train_yajie_list[x].extend([float(i) for i in line.split()])
        x += 1

    lines.close()

train_yajie = np.array(train_yajie_list)
print(train_yajie)
print(type(train_yajie), train_yajie.shape, train_yajie.size)




# ----------------------------------------------------------------------------------------------------------------------------------------------




train_yaxu_label = open('/Users/micheng/PycharmProjects/dissertation_project/ISRMyo-I-master/emgData/train_yaxu/y.txt',
               'r')
train_yaxu_1 = open('/Users/micheng/PycharmProjects/dissertation_project/ISRMyo-I-master/emgData/train_yaxu/C01_train.txt',
               'r')
train_yaxu_2 = open('/Users/micheng/PycharmProjects/dissertation_project/ISRMyo-I-master/emgData/train_yaxu/C02_train.txt',
               'r')
train_yaxu_3 = open('/Users/micheng/PycharmProjects/dissertation_project/ISRMyo-I-master/emgData/train_yaxu/C03_train.txt',
               'r')
train_yaxu_4 = open('/Users/micheng/PycharmProjects/dissertation_project/ISRMyo-I-master/emgData/train_yaxu/C04_train.txt',
               'r')
train_yaxu_5 = open('/Users/micheng/PycharmProjects/dissertation_project/ISRMyo-I-master/emgData/train_yaxu/C05_train.txt',
               'r')
train_yaxu_6 = open('/Users/micheng/PycharmProjects/dissertation_project/ISRMyo-I-master/emgData/train_yaxu/C06_train.txt',
               'r')
train_yaxu_7 = open('/Users/micheng/PycharmProjects/dissertation_project/ISRMyo-I-master/emgData/train_yaxu/C07_train.txt',
               'r')
train_yaxu_8 = open('/Users/micheng/PycharmProjects/dissertation_project/ISRMyo-I-master/emgData/train_yaxu/C08_train.txt',
               'r')
train_yaxu_9 = open('/Users/micheng/PycharmProjects/dissertation_project/ISRMyo-I-master/emgData/train_yaxu/C09_train.txt',
               'r')
train_yaxu_10 = open('/Users/micheng/PycharmProjects/dissertation_project/ISRMyo-I-master/emgData/train_yaxu/C10_train.txt',
               'r')
train_yaxu_11 = open('/Users/micheng/PycharmProjects/dissertation_project/ISRMyo-I-master/emgData/train_yaxu/C11_train.txt',
               'r')
train_yaxu_12 = open('/Users/micheng/PycharmProjects/dissertation_project/ISRMyo-I-master/emgData/train_yaxu/C12_train.txt',
               'r')
train_yaxu_13 = open('/Users/micheng/PycharmProjects/dissertation_project/ISRMyo-I-master/emgData/train_yaxu/C13_train.txt',
               'r')
train_yaxu_14 = open('/Users/micheng/PycharmProjects/dissertation_project/ISRMyo-I-master/emgData/train_yaxu/C14_train.txt',
               'r')
train_yaxu_15 = open('/Users/micheng/PycharmProjects/dissertation_project/ISRMyo-I-master/emgData/train_yaxu/C15_train.txt',
               'r')
train_yaxu_16 = open('/Users/micheng/PycharmProjects/dissertation_project/ISRMyo-I-master/emgData/train_yaxu/C16_train.txt',
               'r')

train_name = [train_yaxu_label, train_yaxu_1, train_yaxu_2, train_yaxu_3, train_yaxu_4, train_yaxu_5,
              train_yaxu_6, train_yaxu_7, train_yaxu_8, train_yaxu_9, train_yaxu_10, train_yaxu_11,
              train_yaxu_12, train_yaxu_13, train_yaxu_14, train_yaxu_15, train_yaxu_16]

train_yaxu_list = [[] for i in range(13650)]

for index, lines in enumerate(train_name):
    x = 0
    for line in lines.readlines():
        # print(line)
        train_yaxu_list[x].extend([float(i) for i in line.split()])
        x += 1

    lines.close()

train_yaxu = np.array(train_yaxu_list)
print(train_yaxu)
print(type(train_yaxu), train_yaxu.shape, train_yaxu.size)




# ----------------------------------------------------------------------------------------------------------------------------------------------




train_yinfeng_label = open('/Users/micheng/PycharmProjects/dissertation_project/ISRMyo-I-master/emgData/train_yinfeng/y.txt',
               'r')
train_yinfeng_1 = open('/Users/micheng/PycharmProjects/dissertation_project/ISRMyo-I-master/emgData/train_yinfeng/C01_train.txt',
               'r')
train_yinfeng_2 = open('/Users/micheng/PycharmProjects/dissertation_project/ISRMyo-I-master/emgData/train_yinfeng/C02_train.txt',
               'r')
train_yinfeng_3 = open('/Users/micheng/PycharmProjects/dissertation_project/ISRMyo-I-master/emgData/train_yinfeng/C03_train.txt',
               'r')
train_yinfeng_4 = open('/Users/micheng/PycharmProjects/dissertation_project/ISRMyo-I-master/emgData/train_yinfeng/C04_train.txt',
               'r')
train_yinfeng_5 = open('/Users/micheng/PycharmProjects/dissertation_project/ISRMyo-I-master/emgData/train_yinfeng/C05_train.txt',
               'r')
train_yinfeng_6 = open('/Users/micheng/PycharmProjects/dissertation_project/ISRMyo-I-master/emgData/train_yinfeng/C06_train.txt',
               'r')
train_yinfeng_7 = open('/Users/micheng/PycharmProjects/dissertation_project/ISRMyo-I-master/emgData/train_yinfeng/C07_train.txt',
               'r')
train_yinfeng_8 = open('/Users/micheng/PycharmProjects/dissertation_project/ISRMyo-I-master/emgData/train_yinfeng/C08_train.txt',
               'r')
train_yinfeng_9 = open('/Users/micheng/PycharmProjects/dissertation_project/ISRMyo-I-master/emgData/train_yinfeng/C09_train.txt',
               'r')
train_yinfeng_10 = open('/Users/micheng/PycharmProjects/dissertation_project/ISRMyo-I-master/emgData/train_yinfeng/C10_train.txt',
               'r')
train_yinfeng_11 = open('/Users/micheng/PycharmProjects/dissertation_project/ISRMyo-I-master/emgData/train_yinfeng/C11_train.txt',
               'r')
train_yinfeng_12 = open('/Users/micheng/PycharmProjects/dissertation_project/ISRMyo-I-master/emgData/train_yinfeng/C12_train.txt',
               'r')
train_yinfeng_13 = open('/Users/micheng/PycharmProjects/dissertation_project/ISRMyo-I-master/emgData/train_yinfeng/C13_train.txt',
               'r')
train_yinfeng_14 = open('/Users/micheng/PycharmProjects/dissertation_project/ISRMyo-I-master/emgData/train_yinfeng/C14_train.txt',
               'r')
train_yinfeng_15 = open('/Users/micheng/PycharmProjects/dissertation_project/ISRMyo-I-master/emgData/train_yinfeng/C15_train.txt',
               'r')
train_yinfeng_16 = open('/Users/micheng/PycharmProjects/dissertation_project/ISRMyo-I-master/emgData/train_yinfeng/C16_train.txt',
               'r')

train_name = [train_yinfeng_label, train_yinfeng_1, train_yinfeng_2, train_yinfeng_3, train_yinfeng_4, train_yinfeng_5,
              train_yinfeng_6, train_yinfeng_7, train_yinfeng_8, train_yinfeng_9, train_yinfeng_10, train_yinfeng_11,
              train_yinfeng_12, train_yinfeng_13, train_yinfeng_14, train_yinfeng_15, train_yinfeng_16]

train_yinfeng_list = [[] for i in range(13650)]

for index, lines in enumerate(train_name):
    x = 0
    for line in lines.readlines():
        # print(line)
        train_yinfeng_list[x].extend([float(i) for i in line.split()])
        x += 1

    lines.close()

train_yinfeng = np.array(train_yinfeng_list)
print(train_yinfeng)
print(type(train_yinfeng), train_yinfeng.shape, train_yinfeng.size)







"""

    test set for six persons.

"""






test_bangli_label = open('/Users/micheng/PycharmProjects/dissertation_project/ISRMyo-I-master/emgData/test_bangli/y.txt',
               'r')
test_bangli_1 = open('/Users/micheng/PycharmProjects/dissertation_project/ISRMyo-I-master/emgData/test_bangli/C01_test.txt',
               'r')
test_bangli_2 = open('/Users/micheng/PycharmProjects/dissertation_project/ISRMyo-I-master/emgData/test_bangli/C02_test.txt',
               'r')
test_bangli_3 = open('/Users/micheng/PycharmProjects/dissertation_project/ISRMyo-I-master/emgData/test_bangli/C03_test.txt',
               'r')
test_bangli_4 = open('/Users/micheng/PycharmProjects/dissertation_project/ISRMyo-I-master/emgData/test_bangli/C04_test.txt',
               'r')
test_bangli_5 = open('/Users/micheng/PycharmProjects/dissertation_project/ISRMyo-I-master/emgData/test_bangli/C05_test.txt',
               'r')
test_bangli_6 = open('/Users/micheng/PycharmProjects/dissertation_project/ISRMyo-I-master/emgData/test_bangli/C06_test.txt',
               'r')
test_bangli_7 = open('/Users/micheng/PycharmProjects/dissertation_project/ISRMyo-I-master/emgData/test_bangli/C07_test.txt',
               'r')
test_bangli_8 = open('/Users/micheng/PycharmProjects/dissertation_project/ISRMyo-I-master/emgData/test_bangli/C08_test.txt',
               'r')
test_bangli_9 = open('/Users/micheng/PycharmProjects/dissertation_project/ISRMyo-I-master/emgData/test_bangli/C09_test.txt',
               'r')
test_bangli_10 = open('/Users/micheng/PycharmProjects/dissertation_project/ISRMyo-I-master/emgData/test_bangli/C10_test.txt',
               'r')
test_bangli_11 = open('/Users/micheng/PycharmProjects/dissertation_project/ISRMyo-I-master/emgData/test_bangli/C11_test.txt',
               'r')
test_bangli_12 = open('/Users/micheng/PycharmProjects/dissertation_project/ISRMyo-I-master/emgData/test_bangli/C12_test.txt',
               'r')
test_bangli_13 = open('/Users/micheng/PycharmProjects/dissertation_project/ISRMyo-I-master/emgData/test_bangli/C13_test.txt',
               'r')
test_bangli_14 = open('/Users/micheng/PycharmProjects/dissertation_project/ISRMyo-I-master/emgData/test_bangli/C14_test.txt',
               'r')
test_bangli_15 = open('/Users/micheng/PycharmProjects/dissertation_project/ISRMyo-I-master/emgData/test_bangli/C15_test.txt',
               'r')
test_bangli_16 = open('/Users/micheng/PycharmProjects/dissertation_project/ISRMyo-I-master/emgData/test_bangli/C16_test.txt',
               'r')


test_name = [test_bangli_label, test_bangli_1, test_bangli_2, test_bangli_3, test_bangli_4, test_bangli_5,
              test_bangli_6, test_bangli_7, test_bangli_8, test_bangli_9, test_bangli_10, test_bangli_11,
              test_bangli_12, test_bangli_13, test_bangli_14, test_bangli_15, test_bangli_16]

test_bangli_list = [[] for i in range(5850)]

for index, lines in enumerate(test_name):
    x = 0
    for line in lines.readlines():
        # print(line)
        test_bangli_list[x].extend([float(i) for i in line.split()])
        x += 1

    lines.close()

test_bangli = np.array(test_bangli_list)
print(test_bangli)
print(type(test_bangli), test_bangli.shape, test_bangli.size)




# ----------------------------------------------------------------------------------------------------------------------------------------------




test_disi_label = open('/Users/micheng/PycharmProjects/dissertation_project/ISRMyo-I-master/emgData/test_disi/y.txt',
               'r')
test_disi_1 = open('/Users/micheng/PycharmProjects/dissertation_project/ISRMyo-I-master/emgData/test_disi/C01_test.txt',
               'r')
test_disi_2 = open('/Users/micheng/PycharmProjects/dissertation_project/ISRMyo-I-master/emgData/test_disi/C02_test.txt',
               'r')
test_disi_3 = open('/Users/micheng/PycharmProjects/dissertation_project/ISRMyo-I-master/emgData/test_disi/C03_test.txt',
               'r')
test_disi_4 = open('/Users/micheng/PycharmProjects/dissertation_project/ISRMyo-I-master/emgData/test_disi/C04_test.txt',
               'r')
test_disi_5 = open('/Users/micheng/PycharmProjects/dissertation_project/ISRMyo-I-master/emgData/test_disi/C05_test.txt',
               'r')
test_disi_6 = open('/Users/micheng/PycharmProjects/dissertation_project/ISRMyo-I-master/emgData/test_disi/C06_test.txt',
               'r')
test_disi_7 = open('/Users/micheng/PycharmProjects/dissertation_project/ISRMyo-I-master/emgData/test_disi/C07_test.txt',
               'r')
test_disi_8 = open('/Users/micheng/PycharmProjects/dissertation_project/ISRMyo-I-master/emgData/test_disi/C08_test.txt',
               'r')
test_disi_9 = open('/Users/micheng/PycharmProjects/dissertation_project/ISRMyo-I-master/emgData/test_disi/C09_test.txt',
               'r')
test_disi_10 = open('/Users/micheng/PycharmProjects/dissertation_project/ISRMyo-I-master/emgData/test_disi/C10_test.txt',
               'r')
test_disi_11 = open('/Users/micheng/PycharmProjects/dissertation_project/ISRMyo-I-master/emgData/test_disi/C11_test.txt',
               'r')
test_disi_12 = open('/Users/micheng/PycharmProjects/dissertation_project/ISRMyo-I-master/emgData/test_disi/C12_test.txt',
               'r')
test_disi_13 = open('/Users/micheng/PycharmProjects/dissertation_project/ISRMyo-I-master/emgData/test_disi/C13_test.txt',
               'r')
test_disi_14 = open('/Users/micheng/PycharmProjects/dissertation_project/ISRMyo-I-master/emgData/test_disi/C14_test.txt',
               'r')
test_disi_15 = open('/Users/micheng/PycharmProjects/dissertation_project/ISRMyo-I-master/emgData/test_disi/C15_test.txt',
               'r')
test_disi_16 = open('/Users/micheng/PycharmProjects/dissertation_project/ISRMyo-I-master/emgData/test_disi/C16_test.txt',
               'r')

test_name = [test_disi_label, test_disi_1, test_disi_2, test_disi_3, test_disi_4, test_disi_5,
              test_disi_6, test_disi_7, test_disi_8, test_disi_9, test_disi_10, test_disi_11,
              test_disi_12, test_disi_13, test_disi_14, test_disi_15, test_disi_16]

test_disi_list = [[] for i in range(5850)]

for index, lines in enumerate(test_name):
    x = 0
    for line in lines.readlines():
        # print(line)
        test_disi_list[x].extend([float(i) for i in line.split()])
        x += 1

    lines.close()

test_disi = np.array(test_disi_list)
print(test_disi)
print(type(test_disi), test_disi.shape, test_disi.size)




# ----------------------------------------------------------------------------------------------------------------------------------------------




test_kairu_label = open('/Users/micheng/PycharmProjects/dissertation_project/ISRMyo-I-master/emgData/test_kairu/y.txt',
               'r')
test_kairu_1 = open('/Users/micheng/PycharmProjects/dissertation_project/ISRMyo-I-master/emgData/test_kairu/C01_test.txt',
               'r')
test_kairu_2 = open('/Users/micheng/PycharmProjects/dissertation_project/ISRMyo-I-master/emgData/test_kairu/C02_test.txt',
               'r')
test_kairu_3 = open('/Users/micheng/PycharmProjects/dissertation_project/ISRMyo-I-master/emgData/test_kairu/C03_test.txt',
               'r')
test_kairu_4 = open('/Users/micheng/PycharmProjects/dissertation_project/ISRMyo-I-master/emgData/test_kairu/C04_test.txt',
               'r')
test_kairu_5 = open('/Users/micheng/PycharmProjects/dissertation_project/ISRMyo-I-master/emgData/test_kairu/C05_test.txt',
               'r')
test_kairu_6 = open('/Users/micheng/PycharmProjects/dissertation_project/ISRMyo-I-master/emgData/test_kairu/C06_test.txt',
               'r')
test_kairu_7 = open('/Users/micheng/PycharmProjects/dissertation_project/ISRMyo-I-master/emgData/test_kairu/C07_test.txt',
               'r')
test_kairu_8 = open('/Users/micheng/PycharmProjects/dissertation_project/ISRMyo-I-master/emgData/test_kairu/C08_test.txt',
               'r')
test_kairu_9 = open('/Users/micheng/PycharmProjects/dissertation_project/ISRMyo-I-master/emgData/test_kairu/C09_test.txt',
               'r')
test_kairu_10 = open('/Users/micheng/PycharmProjects/dissertation_project/ISRMyo-I-master/emgData/test_kairu/C10_test.txt',
               'r')
test_kairu_11 = open('/Users/micheng/PycharmProjects/dissertation_project/ISRMyo-I-master/emgData/test_kairu/C11_test.txt',
               'r')
test_kairu_12 = open('/Users/micheng/PycharmProjects/dissertation_project/ISRMyo-I-master/emgData/test_kairu/C12_test.txt',
               'r')
test_kairu_13 = open('/Users/micheng/PycharmProjects/dissertation_project/ISRMyo-I-master/emgData/test_kairu/C13_test.txt',
               'r')
test_kairu_14 = open('/Users/micheng/PycharmProjects/dissertation_project/ISRMyo-I-master/emgData/test_kairu/C14_test.txt',
               'r')
test_kairu_15 = open('/Users/micheng/PycharmProjects/dissertation_project/ISRMyo-I-master/emgData/test_kairu/C15_test.txt',
               'r')
test_kairu_16 = open('/Users/micheng/PycharmProjects/dissertation_project/ISRMyo-I-master/emgData/test_kairu/C16_test.txt',
               'r')

test_name = [test_kairu_label, test_kairu_1, test_kairu_2, test_kairu_3, test_kairu_4, test_kairu_5,
              test_kairu_6, test_kairu_7, test_kairu_8, test_kairu_9, test_kairu_10, test_kairu_11,
              test_kairu_12, test_kairu_13, test_kairu_14, test_kairu_15, test_kairu_16]

test_kairu_list = [[] for i in range(5850)]

for index, lines in enumerate(test_name):
    x = 0
    for line in lines.readlines():
        # print(line)
        test_kairu_list[x].extend([float(i) for i in line.split()])
        x += 1

    lines.close()

test_kairu = np.array(test_kairu_list)
print(test_kairu)
print(type(test_kairu), test_kairu.shape, test_kairu.size)




# ----------------------------------------------------------------------------------------------------------------------------------------------




test_yajie_label = open('/Users/micheng/PycharmProjects/dissertation_project/ISRMyo-I-master/emgData/test_yajie/y.txt',
               'r')
test_yajie_1 = open('/Users/micheng/PycharmProjects/dissertation_project/ISRMyo-I-master/emgData/test_yajie/C01_test.txt',
               'r')
test_yajie_2 = open('/Users/micheng/PycharmProjects/dissertation_project/ISRMyo-I-master/emgData/test_yajie/C02_test.txt',
               'r')
test_yajie_3 = open('/Users/micheng/PycharmProjects/dissertation_project/ISRMyo-I-master/emgData/test_yajie/C03_test.txt',
               'r')
test_yajie_4 = open('/Users/micheng/PycharmProjects/dissertation_project/ISRMyo-I-master/emgData/test_yajie/C04_test.txt',
               'r')
test_yajie_5 = open('/Users/micheng/PycharmProjects/dissertation_project/ISRMyo-I-master/emgData/test_yajie/C05_test.txt',
               'r')
test_yajie_6 = open('/Users/micheng/PycharmProjects/dissertation_project/ISRMyo-I-master/emgData/test_yajie/C06_test.txt',
               'r')
test_yajie_7 = open('/Users/micheng/PycharmProjects/dissertation_project/ISRMyo-I-master/emgData/test_yajie/C07_test.txt',
               'r')
test_yajie_8 = open('/Users/micheng/PycharmProjects/dissertation_project/ISRMyo-I-master/emgData/test_yajie/C08_test.txt',
               'r')
test_yajie_9 = open('/Users/micheng/PycharmProjects/dissertation_project/ISRMyo-I-master/emgData/test_yajie/C09_test.txt',
               'r')
test_yajie_10 = open('/Users/micheng/PycharmProjects/dissertation_project/ISRMyo-I-master/emgData/test_yajie/C10_test.txt',
               'r')
test_yajie_11 = open('/Users/micheng/PycharmProjects/dissertation_project/ISRMyo-I-master/emgData/test_yajie/C11_test.txt',
               'r')
test_yajie_12 = open('/Users/micheng/PycharmProjects/dissertation_project/ISRMyo-I-master/emgData/test_yajie/C12_test.txt',
               'r')
test_yajie_13 = open('/Users/micheng/PycharmProjects/dissertation_project/ISRMyo-I-master/emgData/test_yajie/C13_test.txt',
               'r')
test_yajie_14 = open('/Users/micheng/PycharmProjects/dissertation_project/ISRMyo-I-master/emgData/test_yajie/C14_test.txt',
               'r')
test_yajie_15 = open('/Users/micheng/PycharmProjects/dissertation_project/ISRMyo-I-master/emgData/test_yajie/C15_test.txt',
               'r')
test_yajie_16 = open('/Users/micheng/PycharmProjects/dissertation_project/ISRMyo-I-master/emgData/test_yajie/C16_test.txt',
               'r')

test_name = [test_yajie_label, test_yajie_1, test_yajie_2, test_yajie_3, test_yajie_4, test_yajie_5,
              test_yajie_6, test_yajie_7, test_yajie_8, test_yajie_9, test_yajie_10, test_yajie_11,
              test_yajie_12, test_yajie_13, test_yajie_14, test_yajie_15, test_yajie_16]

test_yajie_list = [[] for i in range(5850)]

for index, lines in enumerate(test_name):
    x = 0
    for line in lines.readlines():
        # print(line)
        test_yajie_list[x].extend([float(i) for i in line.split()])
        x += 1

    lines.close()

test_yajie = np.array(test_yajie_list)
print(test_yajie)
print(type(test_yajie), test_yajie.shape, test_yajie.size)




# ----------------------------------------------------------------------------------------------------------------------------------------------




test_yaxu_label = open('/Users/micheng/PycharmProjects/dissertation_project/ISRMyo-I-master/emgData/test_yaxu/y.txt',
               'r')
test_yaxu_1 = open('/Users/micheng/PycharmProjects/dissertation_project/ISRMyo-I-master/emgData/test_yaxu/C01_test.txt',
               'r')
test_yaxu_2 = open('/Users/micheng/PycharmProjects/dissertation_project/ISRMyo-I-master/emgData/test_yaxu/C02_test.txt',
               'r')
test_yaxu_3 = open('/Users/micheng/PycharmProjects/dissertation_project/ISRMyo-I-master/emgData/test_yaxu/C03_test.txt',
               'r')
test_yaxu_4 = open('/Users/micheng/PycharmProjects/dissertation_project/ISRMyo-I-master/emgData/test_yaxu/C04_test.txt',
               'r')
test_yaxu_5 = open('/Users/micheng/PycharmProjects/dissertation_project/ISRMyo-I-master/emgData/test_yaxu/C05_test.txt',
               'r')
test_yaxu_6 = open('/Users/micheng/PycharmProjects/dissertation_project/ISRMyo-I-master/emgData/test_yaxu/C06_test.txt',
               'r')
test_yaxu_7 = open('/Users/micheng/PycharmProjects/dissertation_project/ISRMyo-I-master/emgData/test_yaxu/C07_test.txt',
               'r')
test_yaxu_8 = open('/Users/micheng/PycharmProjects/dissertation_project/ISRMyo-I-master/emgData/test_yaxu/C08_test.txt',
               'r')
test_yaxu_9 = open('/Users/micheng/PycharmProjects/dissertation_project/ISRMyo-I-master/emgData/test_yaxu/C09_test.txt',
               'r')
test_yaxu_10 = open('/Users/micheng/PycharmProjects/dissertation_project/ISRMyo-I-master/emgData/test_yaxu/C10_test.txt',
               'r')
test_yaxu_11 = open('/Users/micheng/PycharmProjects/dissertation_project/ISRMyo-I-master/emgData/test_yaxu/C11_test.txt',
               'r')
test_yaxu_12 = open('/Users/micheng/PycharmProjects/dissertation_project/ISRMyo-I-master/emgData/test_yaxu/C12_test.txt',
               'r')
test_yaxu_13 = open('/Users/micheng/PycharmProjects/dissertation_project/ISRMyo-I-master/emgData/test_yaxu/C13_test.txt',
               'r')
test_yaxu_14 = open('/Users/micheng/PycharmProjects/dissertation_project/ISRMyo-I-master/emgData/test_yaxu/C14_test.txt',
               'r')
test_yaxu_15 = open('/Users/micheng/PycharmProjects/dissertation_project/ISRMyo-I-master/emgData/test_yaxu/C15_test.txt',
               'r')
test_yaxu_16 = open('/Users/micheng/PycharmProjects/dissertation_project/ISRMyo-I-master/emgData/test_yaxu/C16_test.txt',
               'r')

test_name = [test_yaxu_label, test_yaxu_1, test_yaxu_2, test_yaxu_3, test_yaxu_4, test_yaxu_5,
              test_yaxu_6, test_yaxu_7, test_yaxu_8, test_yaxu_9, test_yaxu_10, test_yaxu_11,
              test_yaxu_12, test_yaxu_13, test_yaxu_14, test_yaxu_15, test_yaxu_16]

test_yaxu_list = [[] for i in range(5850)]

for index, lines in enumerate(test_name):
    x = 0
    for line in lines.readlines():
        # print(line)
        test_yaxu_list[x].extend([float(i) for i in line.split()])
        x += 1

    lines.close()

test_yaxu = np.array(test_yaxu_list)
print(test_yaxu)
print(type(test_yaxu), test_yaxu.shape, test_yaxu.size)




# ----------------------------------------------------------------------------------------------------------------------------------------------




test_yinfeng_label = open('/Users/micheng/PycharmProjects/dissertation_project/ISRMyo-I-master/emgData/test_yinfeng/y.txt',
               'r')
test_yinfeng_1 = open('/Users/micheng/PycharmProjects/dissertation_project/ISRMyo-I-master/emgData/test_yinfeng/C01_test.txt',
               'r')
test_yinfeng_2 = open('/Users/micheng/PycharmProjects/dissertation_project/ISRMyo-I-master/emgData/test_yinfeng/C02_test.txt',
               'r')
test_yinfeng_3 = open('/Users/micheng/PycharmProjects/dissertation_project/ISRMyo-I-master/emgData/test_yinfeng/C03_test.txt',
               'r')
test_yinfeng_4 = open('/Users/micheng/PycharmProjects/dissertation_project/ISRMyo-I-master/emgData/test_yinfeng/C04_test.txt',
               'r')
test_yinfeng_5 = open('/Users/micheng/PycharmProjects/dissertation_project/ISRMyo-I-master/emgData/test_yinfeng/C05_test.txt',
               'r')
test_yinfeng_6 = open('/Users/micheng/PycharmProjects/dissertation_project/ISRMyo-I-master/emgData/test_yinfeng/C06_test.txt',
               'r')
test_yinfeng_7 = open('/Users/micheng/PycharmProjects/dissertation_project/ISRMyo-I-master/emgData/test_yinfeng/C07_test.txt',
               'r')
test_yinfeng_8 = open('/Users/micheng/PycharmProjects/dissertation_project/ISRMyo-I-master/emgData/test_yinfeng/C08_test.txt',
               'r')
test_yinfeng_9 = open('/Users/micheng/PycharmProjects/dissertation_project/ISRMyo-I-master/emgData/test_yinfeng/C09_test.txt',
               'r')
test_yinfeng_10 = open('/Users/micheng/PycharmProjects/dissertation_project/ISRMyo-I-master/emgData/test_yinfeng/C10_test.txt',
               'r')
test_yinfeng_11 = open('/Users/micheng/PycharmProjects/dissertation_project/ISRMyo-I-master/emgData/test_yinfeng/C11_test.txt',
               'r')
test_yinfeng_12 = open('/Users/micheng/PycharmProjects/dissertation_project/ISRMyo-I-master/emgData/test_yinfeng/C12_test.txt',
               'r')
test_yinfeng_13 = open('/Users/micheng/PycharmProjects/dissertation_project/ISRMyo-I-master/emgData/test_yinfeng/C13_test.txt',
               'r')
test_yinfeng_14 = open('/Users/micheng/PycharmProjects/dissertation_project/ISRMyo-I-master/emgData/test_yinfeng/C14_test.txt',
               'r')
test_yinfeng_15 = open('/Users/micheng/PycharmProjects/dissertation_project/ISRMyo-I-master/emgData/test_yinfeng/C15_test.txt',
               'r')
test_yinfeng_16 = open('/Users/micheng/PycharmProjects/dissertation_project/ISRMyo-I-master/emgData/test_yinfeng/C16_test.txt',
               'r')

test_name = [test_yinfeng_label, test_yinfeng_1, test_yinfeng_2, test_yinfeng_3, test_yinfeng_4, test_yinfeng_5,
              test_yinfeng_6, test_yinfeng_7, test_yinfeng_8, test_yinfeng_9, test_yinfeng_10, test_yinfeng_11,
              test_yinfeng_12, test_yinfeng_13, test_yinfeng_14, test_yinfeng_15, test_yinfeng_16]

test_yinfeng_list = [[] for i in range(5850)]

for index, lines in enumerate(test_name):
    x = 0
    for line in lines.readlines():
        # print(line)
        test_yinfeng_list[x].extend([float(i) for i in line.split()])
        x += 1

    lines.close()

test_yinfeng = np.array(test_yinfeng_list)
print(test_yinfeng)
print(type(test_yinfeng), test_yinfeng.shape, test_yinfeng.size)







"""
    Create h5py file/database of ISRMyo-I
    create_dataset ： 新建 dataset
    create_group ：   新建 group
    keys() ： 获取本文件夹下所有的文件及文件夹的名字
    f['key_name'] : 获取对应的对象 

"""





with h5py.File('ISRMyo-I.h5', 'w') as f:
    train_set = f.create_group('train_set')

    train_bangli = train_set.create_dataset('train_bangli', data=train_bangli)
    train_disi = train_set.create_dataset('train_disi', data=train_disi)
    train_kairu = train_set.create_dataset('train_kairu', data=train_kairu)
    train_yajie = train_set.create_dataset('train_yajie', data=train_yajie)
    train_yaxu = train_set.create_dataset('train_yaxu', data=train_yaxu)
    train_yinfeng = train_set.create_dataset('train_yinfeng', data=train_yinfeng)

    test_set = f.create_group('test_set')

    test_bangli = test_set.create_dataset('test_bangli', data=test_bangli)
    test_disi = test_set.create_dataset('test_disi', data=test_disi)
    test_kairu = test_set.create_dataset('test_kairu', data=test_kairu)
    test_yajie = test_set.create_dataset('test_yajie', data=test_yajie)
    test_yaxu = test_set.create_dataset('test_yaxu', data=test_yaxu)
    test_yinfeng = test_set.create_dataset('test_yinfeng', data=test_yinfeng)


f.close()

