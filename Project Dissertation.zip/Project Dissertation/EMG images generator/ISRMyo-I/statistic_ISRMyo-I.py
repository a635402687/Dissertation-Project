import numpy as np
import matplotlib.pyplot as plt

accu_list_RegNetX = [0.844, 0.843, 0.871, 0.735, 0.897, 0.857]
accu_list_ResNeSt = [0.858, 0.845, 0.883, 0.741, 0.914, 0.880]
accu_list_ResNet = [0.827, 0.841, 0.875, 0.704, 0.893, 0.828]
accu_list_Basic = [0.821, 0.829, 0.864, 0.681, 0.891, 0.819]

accu_RegNetX = np.array(accu_list_RegNetX)
accu_ResNeSt = np.array(accu_list_ResNeSt)
accu_ResNet = np.array(accu_list_ResNet)
accu_Basic = np.array(accu_list_Basic)

avg_accu_RegNetX = np.mean(accu_RegNetX)
avg_accu_ResNeSt = np.mean(accu_ResNeSt)
avg_accu_ResNet = np.mean(accu_ResNet)
avg_accu_Basic = np.mean(accu_Basic)

print(avg_accu_RegNetX, avg_accu_ResNeSt, avg_accu_ResNet, avg_accu_Basic)

a=np.loadtxt("Training_his_ISR_ResNet/Train_loss_his_s1.txt", delimiter=',')
b=np.loadtxt("Training_his_ISR_ResNet/Train_loss_his_s2.txt", delimiter=',')
c=np.loadtxt("Training_his_ISR_ResNet/Train_loss_his_s3.txt", delimiter=',')
d=np.loadtxt("Training_his_ISR_ResNet/Train_loss_his_s4.txt", delimiter=',')
e=np.loadtxt("Training_his_ISR_ResNet/Train_loss_his_s5.txt", delimiter=',')
f=np.loadtxt("Training_his_ISR_ResNet/Train_loss_his_s6.txt", delimiter=',')


# a=np.loadtxt("Training_his_ISR_ResNet/Train_Acc_his_s1.txt", delimiter=',')
# b=np.loadtxt("Training_his_ISR_ResNet/Train_Acc_his_s2.txt", delimiter=',')
# c=np.loadtxt("Training_his_ISR_ResNet/Train_Acc_his_s3.txt", delimiter=',')
# d=np.loadtxt("Training_his_ISR_ResNet/Train_Acc_his_s4.txt", delimiter=',')
# e=np.loadtxt("Training_his_ISR_ResNet/Train_Acc_his_s5.txt", delimiter=',')
# f=np.loadtxt("Training_his_ISR_ResNet/Train_Acc_his_s6.txt", delimiter=',')


# a=np.loadtxt("Training_his_ISR_ResNet/Test_Acc_his_s1.txt", delimiter=',')
# b=np.loadtxt("Training_his_ISR_ResNet/Test_Acc_his_s2.txt", delimiter=',')
# c=np.loadtxt("Training_his_ISR_ResNet/Test_Acc_his_s3.txt", delimiter=',')
# d=np.loadtxt("Training_his_ISR_ResNet/Test_Acc_his_s4.txt", delimiter=',')
# e=np.loadtxt("Training_his_ISR_ResNet/Test_Acc_his_s5.txt", delimiter=',')
# f=np.loadtxt("Training_his_ISR_ResNet/Test_Acc_his_s6.txt", delimiter=',')


plt.style.use(['science','ieee', 'grid', 'no-latex'])
plt.title('Train Loss')
# plt.title('Test Accuracy')
# plt.title('Train Accuracy')

plt.plot(a, linestyle='-', color = 'green')
plt.plot(b, linestyle='-', color = 'blue')
plt.plot(c, linestyle='-', color = 'tomato')
plt.plot(d, linestyle='-', color = 'black')
plt.plot(e, linestyle='-', color = 'blueviolet')
plt.plot(f, linestyle='-', color = 'red')
# plt.legend(loc=0, prop={'size': 5})

plt.xlabel("Epoch")
# plt.ylabel("Accuracy")
plt.ylabel("Loss")
plt.show()
