import numpy as np
import h5py


Database1 = h5py.File('NINAPRO_1_E1.h5', 'r')
Database2 = h5py.File('NINAPRO_1_E2.h5', 'r')
Database3 = h5py.File('NINAPRO_1_E3.h5', 'r')
Database4 = h5py.File('NINAPRO_1_E4.h5', 'r')
Database5 = h5py.File('NINAPRO_1_E5.h5', 'r')
Database6 = h5py.File('NINAPRO_1_E6.h5', 'r')
Database7 = h5py.File('NINAPRO_1_E7.h5', 'r')
Database8 = h5py.File('NINAPRO_1_E8.h5', 'r')
Database9 = h5py.File('NINAPRO_1_E9.h5', 'r')
Database10 = h5py.File('NINAPRO_1_E10.h5', 'r')
Database11 = h5py.File('NINAPRO_1_E11.h5', 'r')
Database12 = h5py.File('NINAPRO_1_E12.h5', 'r')
Database13 = h5py.File('NINAPRO_1_E13.h5', 'r')
Database14 = h5py.File('NINAPRO_1_E14.h5', 'r')
Database15 = h5py.File('NINAPRO_1_E15.h5', 'r')
Database16 = h5py.File('NINAPRO_1_E16.h5', 'r')
Database17 = h5py.File('NINAPRO_1_E17.h5', 'r')
Database18 = h5py.File('NINAPRO_1_E18.h5', 'r')
Database19 = h5py.File('NINAPRO_1_E19.h5', 'r')
Database20 = h5py.File('NINAPRO_1_E20.h5', 'r')
Database21 = h5py.File('NINAPRO_1_E21.h5', 'r')
Database22 = h5py.File('NINAPRO_1_E22.h5', 'r')
Database23 = h5py.File('NINAPRO_1_E23.h5', 'r')
Database24 = h5py.File('NINAPRO_1_E24.h5', 'r')
Database25 = h5py.File('NINAPRO_1_E25.h5', 'r')
Database26 = h5py.File('NINAPRO_1_E26.h5', 'r')
Database27 = h5py.File('NINAPRO_1_E27.h5', 'r')

Data1 = Database1['E1']
train1 = Data1['E1_train']
test1 = Data1['E1_test']
print(train1.shape, test1.shape)

Data2 = Database2['E2']
train2 = Data2['E2_train']
test2 = Data2['E2_test']
print(train2.shape, test2.shape)

Data3 = Database3['E3']
train3 = Data3['E3_train']
test3 = Data3['E3_test']
print(train3.shape, test3.shape)

Data4 = Database4['E4']
train4 = Data4['E4_train']
test4 = Data4['E4_test']
print(train4.shape, test4.shape)

Data5 = Database5['E5']
train5 = Data5['E5_train']
test5 = Data5['E5_test']
print(train5.shape, test5.shape)

Data6 = Database6['E6']
train6 = Data6['E6_train']
test6 = Data6['E6_test']
print(train6.shape, test6.shape)

Data7 = Database7['E7']
train7 = Data7['E7_train']
test7 = Data7['E7_test']
print(train7.shape, test7.shape)

Data8 = Database8['E8']
train8 = Data8['E8_train']
test8 = Data8['E8_test']
print(train8.shape, test8.shape)

Data9 = Database9['E9']
train9 = Data9['E9_train']
test9 = Data9['E9_test']
print(train9.shape, test9.shape)

Data10 = Database10['E10']
train10 = Data10['E10_train']
test10 = Data10['E10_test']
print(train10.shape, test10.shape)

Data11 = Database11['E11']
train11 = Data11['E11_train']
test11 = Data11['E11_test']
print(train11.shape, test11.shape)

Data12 = Database12['E12']
train12 = Data12['E12_train']
test12 = Data12['E12_test']
print(train12.shape, test12.shape)

Data13 = Database13['E13']
train13 = Data13['E13_train']
test13 = Data13['E13_test']
print(train13.shape, test13.shape)

Data14 = Database14['E14']
train14 = Data14['E14_train']
test14 = Data14['E14_test']
print(train14.shape, test14.shape)

Data15 = Database15['E15']
train15 = Data15['E15_train']
test15 = Data15['E15_test']
print(train15.shape, test15.shape)

Data16 = Database16['E16']
train16 = Data16['E16_train']
test16 = Data16['E16_test']
print(train16.shape, test16.shape)

Data17 = Database17['E17']
train17 = Data17['E17_train']
test17 = Data17['E17_test']
print(train17.shape, test17.shape)

Data18 = Database18['E18']
train18 = Data18['E18_train']
test18 = Data18['E18_test']
print(train18.shape, test18.shape)

Data19 = Database19['E19']
train19 = Data19['E19_train']
test19 = Data19['E19_test']
print(train19.shape, test19.shape)

Data20 = Database20['E20']
train20 = Data20['E20_train']
test20 = Data20['E20_test']
print(train20.shape, test20.shape)

Data21 = Database21['E21']
train21 = Data21['E21_train']
test21 = Data21['E21_test']
print(train21.shape, test21.shape)

Data22 = Database22['E22']
train22 = Data22['E22_train']
test22 = Data22['E22_test']
print(train22.shape, test22.shape)

Data23 = Database23['E23']
train23 = Data23['E23_train']
test23 = Data23['E23_test']
print(train23.shape, test23.shape)

Data24 = Database24['E24']
train24 = Data24['E24_train']
test24 = Data24['E24_test']
print(train24.shape, test24.shape)

Data25 = Database25['E25']
train25 = Data25['E25_train']
test25 = Data25['E25_test']
print(train25.shape, test25.shape)

Data26 = Database26['E26']
train26 = Data26['E26_train']
test26 = Data26['E26_test']
print(train26.shape, test26.shape)

Data27 = Database27['E27']
train27 = Data27['E27_train']
test27 = Data27['E27_test']
print(train27.shape, test27.shape)



with h5py.File('NINAPRO_1.h5', 'w') as f:
    dt = h5py.special_dtype(vlen=np.dtype('float64'))  # this is fine

    train1 = np.array(train1)
    test1 = np.array(test1)
    E1_train = train1
    E1_test = test1

    train2 = np.array(train2)
    test2 = np.array(test2)
    E2_train = train2
    E2_test = test2

    train3 = np.array(train3)
    test3 = np.array(test3)
    E3_train = train3
    E3_test = test3

    train4 = np.array(train4)
    test4 = np.array(test4)
    E4_train = train4
    E4_test = test4

    train5 = np.array(train5)
    test5 = np.array(test5)
    E5_train = train5
    E5_test = test5

    train6 = np.array(train6)
    test6 = np.array(test6)
    E6_train = train6
    E6_test = test6

    train7 = np.array(train7)
    test7 = np.array(test7)
    E7_train = train7
    E7_test = test7

    train8 = np.array(train8)
    test8 = np.array(test8)
    E8_train = train8
    E8_test = test8

    train9 = np.array(train9)
    test9 = np.array(test9)
    E9_train = train9
    E9_test = test9

    train10 = np.array(train10)
    test10 = np.array(test10)
    E10_train = train10
    E10_test = test10

    train11 = np.array(train11)
    test11 = np.array(test11)
    E11_train = train11
    E11_test = test11

    train12 = np.array(train12)
    test12 = np.array(test12)
    E12_train = train12
    E12_test = test12

    train13 = np.array(train13)
    test13 = np.array(test13)
    E13_train = train13
    E13_test = test13

    train14 = np.array(train14)
    test14 = np.array(test14)
    E14_train = train14
    E14_test = test14

    train15 = np.array(train15)
    test15 = np.array(test15)
    E15_train = train15
    E15_test = test15

    train16 = np.array(train16)
    test16 = np.array(test16)
    E16_train = train16
    E16_test = test16

    train17 = np.array(train17)
    test17 = np.array(test17)
    E17_train = train17
    E17_test = test17

    train18 = np.array(train18)
    test18 = np.array(test18)
    E18_train = train18
    E18_test = test18

    train19 = np.array(train19)
    test19 = np.array(test19)
    E19_train = train19
    E19_test = test19

    train20 = np.array(train20)
    test20 = np.array(test20)
    E20_train = train20
    E20_test = test20

    train21 = np.array(train21)
    test21 = np.array(test21)
    E21_train = train21
    E21_test = test21

    train22 = np.array(train22)
    test22 = np.array(test22)
    E22_train = train22
    E22_test = test22

    train23 = np.array(train23)
    test23 = np.array(test23)
    E23_train = train23
    E23_test = test23

    train24 = np.array(train24)
    test24 = np.array(test24)
    E24_train = train24
    E24_test = test24

    train25 = np.array(train25)
    test25 = np.array(test25)
    E25_train = train25
    E25_test = test25

    train26 = np.array(train26)
    test26 = np.array(test26)
    E26_train = train26
    E26_test = test26

    train27 = np.array(train27)
    test27 = np.array(test27)
    E27_train = train27
    E27_test = test27


    data1 = f.create_group('E1')

    data1.create_dataset('E1_train', data=E1_train)
    data1.create_dataset('E1_test', data=E1_test)


    data2 = f.create_group('E2')

    data2.create_dataset('E2_train', data=E2_train)
    data2.create_dataset('E2_test', data=E2_test)


    data3 = f.create_group('E3')

    data3.create_dataset('E3_train', data=E3_train)
    data3.create_dataset('E3_test', data=E3_test)


    data4 = f.create_group('E4')

    data4.create_dataset('E4_train', data=E4_train)
    data4.create_dataset('E4_test', data=E4_test)


    data5 = f.create_group('E5')

    data5.create_dataset('E5_train', data=E5_train)
    data5.create_dataset('E5_test', data=E5_test)


    data6 = f.create_group('E6')

    data6.create_dataset('E6_train', data=E6_train)
    data6.create_dataset('E6_test', data=E6_test)


    data7 = f.create_group('E7')

    data7.create_dataset('E7_train', data=E7_train)
    data7.create_dataset('E7_test', data=E7_test)


    data8 = f.create_group('E8')

    data8.create_dataset('E8_train', data=E8_train)
    data8.create_dataset('E8_test', data=E8_test)


    data9 = f.create_group('E9')

    data9.create_dataset('E9_train', data=E9_train)
    data9.create_dataset('E9_test', data=E9_test)


    data10 = f.create_group('E10')

    data10.create_dataset('E10_train', data=E10_train)
    data10.create_dataset('E10_test', data=E10_test)


    data11 = f.create_group('E11')

    data11.create_dataset('E11_train', data=E11_train)
    data11.create_dataset('E11_test', data=E11_test)


    data12 = f.create_group('E12')

    data12.create_dataset('E12_train', data=E12_train)
    data12.create_dataset('E12_test', data=E12_test)


    data13 = f.create_group('E13')

    data13.create_dataset('E13_train', data=E13_train)
    data13.create_dataset('E13_test', data=E13_test)


    data14 = f.create_group('E14')

    data14.create_dataset('E14_train', data=E14_train)
    data14.create_dataset('E14_test', data=E14_test)


    data15 = f.create_group('E15')

    data15.create_dataset('E15_train', data=E15_train)
    data15.create_dataset('E15_test', data=E15_test)


    data16 = f.create_group('E16')

    data16.create_dataset('E16_train', data=E16_train)
    data16.create_dataset('E16_test', data=E16_test)


    data17 = f.create_group('E17')

    data17.create_dataset('E17_train', data=E17_train)
    data17.create_dataset('E17_test', data=E17_test)


    data18 = f.create_group('E18')

    data18.create_dataset('E18_train', data=E18_train)
    data18.create_dataset('E18_test', data=E18_test)


    data19 = f.create_group('E19')

    data19.create_dataset('E19_train', data=E19_train)
    data19.create_dataset('E19_test', data=E19_test)


    data20 = f.create_group('E20')

    data20.create_dataset('E20_train', data=E20_train)
    data20.create_dataset('E20_test', data=E20_test)


    data21 = f.create_group('E21')

    data21.create_dataset('E21_train', data=E21_train)
    data21.create_dataset('E21_test', data=E21_test)


    data22 = f.create_group('E22')

    data22.create_dataset('E22_train', data=E22_train)
    data22.create_dataset('E22_test', data=E22_test)


    data23 = f.create_group('E23')

    data23.create_dataset('E23_train', data=E23_train)
    data23.create_dataset('E23_test', data=E23_test)


    data24 = f.create_group('E24')

    data24.create_dataset('E24_train', data=E24_train)
    data24.create_dataset('E24_test', data=E24_test)


    data25 = f.create_group('E25')

    data25.create_dataset('E25_train', data=E25_train)
    data25.create_dataset('E25_test', data=E25_test)


    data26 = f.create_group('E26')

    data26.create_dataset('E26_train', data=E26_train)
    data26.create_dataset('E26_test', data=E26_test)


    data27 = f.create_group('E27')

    data27.create_dataset('E27_train', data=E27_train)
    data27.create_dataset('E27_test', data=E27_test)

f.close()

Databasesum = h5py.File('NINAPRO_1.h5', 'r')

Data_E1 = Databasesum['E20']

trainx = Data_E1['E20_train']
testx = Data_E1['E20_test']

print(trainx.shape, testx.shape)

