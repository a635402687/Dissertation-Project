import math
import h5py
import scipy
import random
import torch
import scipy.io as scio
from PIL import Image
from scipy import ndimage

import time
import numpy as np
import scipy.misc
import matplotlib.pyplot as plt
from matplotlib.pyplot import imshow
from IPython.display import SVG
from sklearn.model_selection import train_test_split
from scipy import signal

"""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""



subject-1



"""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""
def butter_lowpass_filtfilt(data, order=1):
    # b, a = signal.butter(order, 0.04, 'lowpass', analog=False)
    b, a = signal.butter(order, 0.02, 'lowpass')
    # print('before', data)
    output = signal.filtfilt(b, a, data, axis=0)
    # print('after', data)
    return output

M_1_1 = []
M_1_2 = []
M_1_3 = []
M_1_4 = []
M_1_5 = []
M_1_6 = []
M_1_7 = []
M_1_8 = []
M_1_9 = []
M_1_10 = []
M_1_11 = []
M_1_12 = []
M_1_13 = []
M_1_14 = []
M_1_15 = []
M_1_16 = []
M_1_17 = []
M_1_18 = []
M_1_19 = []
M_1_20 = []
M_1_21 = []
M_1_22 = []
M_1_23 = []
M_1_24 = []
M_1_25 = []
M_1_26 = []
M_1_27 = []
M_1_28 = []
M_1_29 = []
M_1_30 = []
M_1_31 = []
M_1_32 = []
M_1_33 = []
M_1_34 = []
M_1_35 = []
M_1_36 = []
M_1_37 = []
M_1_38 = []
M_1_39 = []
M_1_40 = []
M_1_41 = []
M_1_42 = []
M_1_43 = []
M_1_44 = []
M_1_45 = []
M_1_46 = []
M_1_47 = []
M_1_48 = []
M_1_49 = []
M_1_50 = []
M_1_51 = []
M_1_52 = []

E1_a = scio.loadmat('/Users/micheng/Downloads/Project dissertation/benchmark databases/doi_10/DB1_s3/S3_A1_E1.mat')
E1_b = scio.loadmat('/Users/micheng/Downloads/Project dissertation/benchmark databases/doi_10/DB1_s3/S3_A1_E2.mat')
E1_c = scio.loadmat('/Users/micheng/Downloads/Project dissertation/benchmark databases/doi_10/DB1_s3/S3_A1_E3.mat')
label_E1_a = E1_a['restimulus']
data_E1_a = E1_a['emg']
dataset_E1_a = np.hstack((label_E1_a, data_E1_a))

label_E1_b = E1_b['restimulus']
data_E1_b = E1_b['emg']
dataset_E1_b = np.hstack((label_E1_b, data_E1_b))

label_E1_c = E1_c['restimulus']
data_E1_c = E1_c['emg']
dataset_E1_c = np.hstack((label_E1_c, data_E1_c))

# print(dataset_E1_a.shape, dataset_E1_b.shape, dataset_E1_c.shape)

for i in range(len(dataset_E1_a)):
    if dataset_E1_a[i][0] != 0:
        if dataset_E1_a[i][0] == 1:
            M_1_1.append(dataset_E1_a[i])
        elif dataset_E1_a[i][0] == 2:
            M_1_2.append(dataset_E1_a[i])
        elif dataset_E1_a[i][0] == 3:
            M_1_3.append(dataset_E1_a[i])
        elif dataset_E1_a[i][0] == 4:
            M_1_4.append(dataset_E1_a[i])
        elif dataset_E1_a[i][0] == 5:
            M_1_5.append(dataset_E1_a[i])
        elif dataset_E1_a[i][0] == 6:
            M_1_6.append(dataset_E1_a[i])
        elif dataset_E1_a[i][0] == 7:
            M_1_7.append(dataset_E1_a[i])
        elif dataset_E1_a[i][0] == 8:
            M_1_8.append(dataset_E1_a[i])
        elif dataset_E1_a[i][0] == 9:
            M_1_9.append(dataset_E1_a[i])
        elif dataset_E1_a[i][0] == 10:
            M_1_10.append(dataset_E1_a[i])
        elif dataset_E1_a[i][0] == 11:
            M_1_11.append(dataset_E1_a[i])
        elif dataset_E1_a[i][0] == 12:
            M_1_12.append(dataset_E1_a[i])

M_1_1_pic = []
M_1_1 = np.array(M_1_1)
# print('before', M_1_1)
# print('after', M_1_1)
M_1_1 = np.delete(M_1_1, 0, axis=1)
M_1_1 = butter_lowpass_filtfilt(M_1_1)

for j in range(int(len(M_1_1) / 4 - 4)):
    x = M_1_1[4 * j:(4 * j) + 20]
    y = x.flatten()
    y = np.insert(y, 0, float(1))
    M_1_1_pic.append(y)
M_1_1_pic = np.array(M_1_1_pic)
M_1_1_train=[]
M_1_1_test=[]
for _ in range(int(len(M_1_1_pic))):
    if (int(len(M_1_1_pic))) * (10 / 50) > _ >= (int(len(M_1_1_pic))) * (5 / 50) or (int(len(M_1_1_pic))) * (25 / 50) > _ >= (int(len(M_1_1_pic))) * (20 / 50) or (int(len(M_1_1_pic))) * (35 / 50) > _ >= (int(len(M_1_1_pic))) * (30 / 50):
        M_1_1_test.append(M_1_1_pic[_])
    else:
        M_1_1_train.append(M_1_1_pic[_])
# print(M_1_1_pic.shape)
M_1_1_train = np.array(M_1_1_train)
M_1_1_test = np.array(M_1_1_test)
# print('M_1_train', M_1_1_train)
print(M_1_1_train.shape, M_1_1_test.shape)


M_1_2_pic = []
M_1_2 = np.array(M_1_2)
M_1_2 = np.delete(M_1_2, 0, axis=1)
M_1_2 = butter_lowpass_filtfilt(M_1_2)

for j in range(int(len(M_1_2) / 4 - 4)):
    x = M_1_2[4 * j:(4 * j) + 20]
    y = x.flatten()
    y = np.insert(y, 0, float(2))
    M_1_2_pic.append(y)
M_1_2_pic = np.array(M_1_2_pic)
M_1_2_train=[]
M_1_2_test=[]
for _ in range(int(len(M_1_2_pic))):
    if (int(len(M_1_2_pic))) * (10 / 50) > _ >= (int(len(M_1_2_pic))) * (5 / 50) or (int(len(M_1_2_pic))) * (25 / 50) > _ >= (int(len(M_1_2_pic))) * (20 / 50) or (int(len(M_1_2_pic))) * (35 / 50) > _ >= (int(len(M_1_2_pic))) * (30 / 50):
        M_1_2_test.append(M_1_2_pic[_])
    else:
        M_1_2_train.append(M_1_2_pic[_])
# print(M_1_2_pic.shape)
M_1_2_train = np.array(M_1_2_train)
M_1_2_test = np.array(M_1_2_test)
# print(M_1_2_train)
print(M_1_2_train.shape, M_1_2_test.shape)


M_1_3_pic = []
M_1_3 = np.array(M_1_3)
M_1_3 = np.delete(M_1_3, 0, axis=1)
M_1_3 = butter_lowpass_filtfilt(M_1_3)

for j in range(int(len(M_1_3) / 4 - 4)):
    x = M_1_3[4 * j:(4 * j) + 20]
    y = x.flatten()
    y = np.insert(y, 0, float(3))
    M_1_3_pic.append(y)
M_1_3_pic = np.array(M_1_3_pic)
M_1_3_train=[]
M_1_3_test=[]
for _ in range(int(len(M_1_3_pic))):
    if (int(len(M_1_3_pic))) * (10 / 50) > _ >= (int(len(M_1_3_pic))) * (5 / 50) or (int(len(M_1_3_pic))) * (25 / 50) > _ >= (int(len(M_1_3_pic))) * (20 / 50) or (int(len(M_1_3_pic))) * (35 / 50) > _ >= (int(len(M_1_3_pic))) * (30 / 50):
        M_1_3_test.append(M_1_3_pic[_])
    else:
        M_1_3_train.append(M_1_3_pic[_])
# print(M_1_3_pic.shape)
M_1_3_train = np.array(M_1_3_train)
M_1_3_test = np.array(M_1_3_test)
print(M_1_3_train.shape, M_1_3_test.shape)


M_1_4_pic = []
M_1_4 = np.array(M_1_4)
M_1_4 = np.delete(M_1_4, 0, axis=1)
M_1_4 = butter_lowpass_filtfilt(M_1_4)
for j in range(int(len(M_1_4) / 4 - 4)):
    x = M_1_4[4 * j:(4 * j) + 20]
    y = x.flatten()
    y = np.insert(y, 0, float(4))
    M_1_4_pic.append(y)
M_1_4_pic = np.array(M_1_4_pic)
M_1_4_train=[]
M_1_4_test=[]
for _ in range(int(len(M_1_4_pic))):
    if (int(len(M_1_4_pic))) * (10 / 50) > _ >= (int(len(M_1_4_pic))) * (5 / 50) or (int(len(M_1_4_pic))) * (25 / 50) > _ >= (int(len(M_1_4_pic))) * (20 / 50) or (int(len(M_1_4_pic))) * (35 / 50) > _ >= (int(len(M_1_4_pic))) * (30 / 50):
        M_1_4_test.append(M_1_4_pic[_])
    else:
        M_1_4_train.append(M_1_4_pic[_])
# print(M_1_4_pic.shape)
M_1_4_train = np.array(M_1_4_train)
M_1_4_test = np.array(M_1_4_test)
print(M_1_4_train.shape, M_1_4_test.shape)


M_1_5_pic = []
M_1_5 = np.array(M_1_5)
M_1_5 = np.delete(M_1_5, 0, axis=1)
M_1_5 = butter_lowpass_filtfilt(M_1_5)
for j in range(int(len(M_1_5) / 4 - 4)):
    x = M_1_5[4 * j:(4 * j) + 20]
    y = x.flatten()
    y = np.insert(y, 0, float(5))
    M_1_5_pic.append(y)
M_1_5_pic = np.array(M_1_5_pic)
M_1_5_train=[]
M_1_5_test=[]
for _ in range(int(len(M_1_5_pic))):
    if (int(len(M_1_5_pic))) * (10 / 50) > _ >= (int(len(M_1_5_pic))) * (5 / 50) or (int(len(M_1_5_pic))) * (25 / 50) > _ >= (int(len(M_1_5_pic))) * (20 / 50) or (int(len(M_1_5_pic))) * (35 / 50) > _ >= (int(len(M_1_5_pic))) * (30 / 50):
        M_1_5_test.append(M_1_5_pic[_])
    else:
        M_1_5_train.append(M_1_5_pic[_])
# print(M_1_5_pic.shape)
M_1_5_train = np.array(M_1_5_train)
M_1_5_test = np.array(M_1_5_test)
print(M_1_5_train.shape, M_1_5_test.shape)


M_1_6_pic = []
M_1_6 = np.array(M_1_6)
M_1_6 = np.delete(M_1_6, 0, axis=1)
M_1_6 = butter_lowpass_filtfilt(M_1_6)
for j in range(int(len(M_1_6) / 4 - 4)):
    x = M_1_6[4 * j:(4 * j) + 20]
    y = x.flatten()
    y = np.insert(y, 0, float(6))
    M_1_6_pic.append(y)
M_1_6_pic = np.array(M_1_6_pic)
M_1_6_train=[]
M_1_6_test=[]
for _ in range(int(len(M_1_6_pic))):
    if (int(len(M_1_6_pic))) * (10 / 50) > _ >= (int(len(M_1_6_pic))) * (5 / 50) or (int(len(M_1_6_pic))) * (25 / 50) > _ >= (int(len(M_1_6_pic))) * (20 / 50) or (int(len(M_1_6_pic))) * (35 / 50) > _ >= (int(len(M_1_6_pic))) * (30 / 50):
        M_1_6_test.append(M_1_6_pic[_])
    else:
        M_1_6_train.append(M_1_6_pic[_])
# print(M_1_6_pic.shape)
M_1_6_train = np.array(M_1_6_train)
M_1_6_test = np.array(M_1_6_test)
print(M_1_6_train.shape, M_1_6_test.shape)


M_1_7_pic = []
M_1_7 = np.array(M_1_7)
M_1_7 = np.delete(M_1_7, 0, axis=1)
M_1_7 = butter_lowpass_filtfilt(M_1_7)
for j in range(int(len(M_1_7) / 4 - 4)):
    x = M_1_7[4 * j:(4 * j) + 20]
    y = x.flatten()
    y = np.insert(y, 0, float(7))
    M_1_7_pic.append(y)
M_1_7_pic = np.array(M_1_7_pic)
M_1_7_train=[]
M_1_7_test=[]
for _ in range(int(len(M_1_7_pic))):
    if (int(len(M_1_7_pic))) * (10 / 50) > _ >= (int(len(M_1_7_pic))) * (5 / 50) or (int(len(M_1_7_pic))) * (25 / 50) > _ >= (int(len(M_1_7_pic))) * (20 / 50) or (int(len(M_1_7_pic))) * (35 / 50) > _ >= (int(len(M_1_7_pic))) * (30 / 50):
        M_1_7_test.append(M_1_7_pic[_])
    else:
        M_1_7_train.append(M_1_7_pic[_])
# print(M_1_7_pic.shape)
M_1_7_train = np.array(M_1_7_train)
M_1_7_test = np.array(M_1_7_test)
print(M_1_7_train.shape, M_1_7_test.shape)


M_1_8_pic = []
M_1_8 = np.array(M_1_8)
M_1_8 = np.delete(M_1_8, 0, axis=1)
M_1_8 = butter_lowpass_filtfilt(M_1_8)
for j in range(int(len(M_1_8) / 4 - 4)):
    x = M_1_8[4 * j:(4 * j) + 20]
    y = x.flatten()
    y = np.insert(y, 0, float(8))
    M_1_8_pic.append(y)
M_1_8_pic = np.array(M_1_8_pic)
M_1_8_train=[]
M_1_8_test=[]
for _ in range(int(len(M_1_8_pic))):
    if (int(len(M_1_8_pic))) * (10 / 50) > _ >= (int(len(M_1_8_pic))) * (5 / 50) or (int(len(M_1_8_pic))) * (25 / 50) > _ >= (int(len(M_1_8_pic))) * (20 / 50) or (int(len(M_1_8_pic))) * (35 / 50) > _ >= (int(len(M_1_8_pic))) * (30 / 50):
        M_1_8_test.append(M_1_8_pic[_])
    else:
        M_1_8_train.append(M_1_8_pic[_])
# print(M_1_8_pic.shape)
M_1_8_train = np.array(M_1_8_train)
M_1_8_test = np.array(M_1_8_test)
print(M_1_8_train.shape, M_1_8_test.shape)


M_1_9_pic = []
M_1_9 = np.array(M_1_9)
M_1_9 = np.delete(M_1_9, 0, axis=1)
M_1_9 = butter_lowpass_filtfilt(M_1_9)
for j in range(int(len(M_1_9) / 4 - 4)):
    x = M_1_9[4 * j:(4 * j) + 20]
    y = x.flatten()
    y = np.insert(y, 0, float(9))
    M_1_9_pic.append(y)
M_1_9_pic = np.array(M_1_9_pic)
M_1_9_train=[]
M_1_9_test=[]
for _ in range(int(len(M_1_9_pic))):
    if (int(len(M_1_9_pic))) * (10 / 50) > _ >= (int(len(M_1_9_pic))) * (5 / 50) or (int(len(M_1_9_pic))) * (25 / 50) > _ >= (int(len(M_1_9_pic))) * (20 / 50) or (int(len(M_1_9_pic))) * (35 / 50) > _ >= (int(len(M_1_9_pic))) * (30 / 50):
        M_1_9_test.append(M_1_9_pic[_])
    else:
        M_1_9_train.append(M_1_9_pic[_])
# print(M_1_9_pic.shape)
M_1_9_train = np.array(M_1_9_train)
M_1_9_test = np.array(M_1_9_test)
print(M_1_9_train.shape, M_1_9_test.shape)


M_1_10_pic = []
M_1_10 = np.array(M_1_10)
M_1_10 = np.delete(M_1_10, 0, axis=1)
M_1_10 = butter_lowpass_filtfilt(M_1_10)
for j in range(int(len(M_1_10) / 4 - 4)):
    x = M_1_10[4 * j:(4 * j) + 20]
    y = x.flatten()
    y = np.insert(y, 0, float(10))
    M_1_10_pic.append(y)
M_1_10_pic = np.array(M_1_10_pic)
M_1_10_train=[]
M_1_10_test=[]
for _ in range(int(len(M_1_10_pic))):
    if (int(len(M_1_10_pic))) * (10 / 50) > _ >= (int(len(M_1_10_pic))) * (5 / 50) or (int(len(M_1_10_pic))) * (25 / 50) > _ >= (int(len(M_1_10_pic))) * (20 / 50) or (int(len(M_1_10_pic))) * (35 / 50) > _ >= (int(len(M_1_10_pic))) * (30 / 50):
        M_1_10_test.append(M_1_10_pic[_])
    else:
        M_1_10_train.append(M_1_10_pic[_])
# print(M_1_10_pic.shape)
M_1_10_train = np.array(M_1_10_train)
M_1_10_test = np.array(M_1_10_test)
print(M_1_10_train.shape, M_1_10_test.shape)


M_1_11_pic = []
M_1_11 = np.array(M_1_11)
M_1_11 = np.delete(M_1_11, 0, axis=1)
M_1_11 = butter_lowpass_filtfilt(M_1_11)
for j in range(int(len(M_1_11) / 4 - 4)):
    x = M_1_11[4 * j:(4 * j) + 20]
    y = x.flatten()
    y = np.insert(y, 0, float(11))
    M_1_11_pic.append(y)
M_1_11_pic = np.array(M_1_11_pic)
M_1_11_train=[]
M_1_11_test=[]
for _ in range(int(len(M_1_11_pic))):
    if (int(len(M_1_11_pic))) * (10 / 50) > _ >= (int(len(M_1_11_pic))) * (5 / 50) or (int(len(M_1_11_pic))) * (25 / 50) > _ >= (int(len(M_1_11_pic))) * (20 / 50) or (int(len(M_1_11_pic))) * (35 / 50) > _ >= (int(len(M_1_11_pic))) * (30 / 50):
        M_1_11_test.append(M_1_11_pic[_])
    else:
        M_1_11_train.append(M_1_11_pic[_])
# print(M_1_11_pic.shape)
M_1_11_train = np.array(M_1_11_train)
M_1_11_test = np.array(M_1_11_test)
print(M_1_11_train.shape, M_1_11_test.shape)


M_1_12_pic = []
M_1_12 = np.array(M_1_12)
M_1_12 = np.delete(M_1_12, 0, axis=1)
M_1_12 = butter_lowpass_filtfilt(M_1_12)
for j in range(int(len(M_1_12) / 4 - 4)):
    x = M_1_12[4 * j:(4 * j) + 20]
    y = x.flatten()
    y = np.insert(y, 0, float(12))
    M_1_12_pic.append(y)
M_1_12_pic = np.array(M_1_12_pic)
M_1_12_train=[]
M_1_12_test=[]
for _ in range(int(len(M_1_12_pic))):
    if (int(len(M_1_12_pic))) * (10 / 50) > _ >= (int(len(M_1_12_pic))) * (5 / 50) or (int(len(M_1_12_pic))) * (25 / 50) > _ >= (int(len(M_1_12_pic))) * (20 / 50) or (int(len(M_1_12_pic))) * (35 / 50) > _ >= (int(len(M_1_12_pic))) * (30 / 50):
        M_1_12_test.append(M_1_12_pic[_])
    else:
        M_1_12_train.append(M_1_12_pic[_])
# print(M_1_12_pic.shape)
M_1_12_train = np.array(M_1_12_train)
M_1_12_test = np.array(M_1_12_test)
print(M_1_12_train.shape, M_1_12_test.shape)


for i in range(len(dataset_E1_b)):
    if dataset_E1_b[i][0] != 0:
        if dataset_E1_b[i][0] == 1:
            dataset_E1_b[i][0] = 13
            M_1_13.append(dataset_E1_b[i])
        elif dataset_E1_b[i][0] == 2:
            dataset_E1_b[i][0] = 14
            M_1_14.append(dataset_E1_b[i])
        elif dataset_E1_b[i][0] == 3:
            dataset_E1_b[i][0] = 15
            M_1_15.append(dataset_E1_b[i])
        elif dataset_E1_b[i][0] == 4:
            dataset_E1_b[i][0] = 16
            M_1_16.append(dataset_E1_b[i])
        elif dataset_E1_b[i][0] == 5:
            dataset_E1_b[i][0] = 17
            M_1_17.append(dataset_E1_b[i])
        elif dataset_E1_b[i][0] == 6:
            dataset_E1_b[i][0] = 18
            M_1_18.append(dataset_E1_b[i])
        elif dataset_E1_b[i][0] == 7:
            dataset_E1_b[i][0] = 19
            M_1_19.append(dataset_E1_b[i])
        elif dataset_E1_b[i][0] == 8:
            dataset_E1_b[i][0] = 20
            M_1_20.append(dataset_E1_b[i])
        elif dataset_E1_b[i][0] == 9:
            dataset_E1_b[i][0] = 21
            M_1_21.append(dataset_E1_b[i])
        elif dataset_E1_b[i][0] == 10:
            dataset_E1_b[i][0] = 22
            M_1_22.append(dataset_E1_b[i])
        elif dataset_E1_b[i][0] == 11:
            dataset_E1_b[i][0] = 23
            M_1_23.append(dataset_E1_b[i])
        elif dataset_E1_b[i][0] == 12:
            dataset_E1_b[i][0] = 24
            M_1_24.append(dataset_E1_b[i])
        elif dataset_E1_b[i][0] == 13:
            dataset_E1_b[i][0] = 25
            M_1_25.append(dataset_E1_b[i])
        elif dataset_E1_b[i][0] == 14:
            dataset_E1_b[i][0] = 26
            M_1_26.append(dataset_E1_b[i])
        elif dataset_E1_b[i][0] == 15:
            dataset_E1_b[i][0] = 27
            M_1_27.append(dataset_E1_b[i])
        elif dataset_E1_b[i][0] == 16:
            dataset_E1_b[i][0] = 28
            M_1_28.append(dataset_E1_b[i])
        elif dataset_E1_b[i][0] == 17:
            dataset_E1_b[i][0] = 29
            M_1_29.append(dataset_E1_b[i])

M_1_13_pic = []
M_1_13 = np.array(M_1_13)
M_1_13 = np.delete(M_1_13, 0, axis=1)
M_1_13 = butter_lowpass_filtfilt(M_1_13)
for j in range(int(len(M_1_13) / 4 - 4)):
    x = M_1_13[4 * j:(4 * j) + 20]
    y = x.flatten()
    y = np.insert(y, 0, float(13))
    M_1_13_pic.append(y)
M_1_13_pic = np.array(M_1_13_pic)
M_1_13_train=[]
M_1_13_test=[]
for _ in range(int(len(M_1_13_pic))):
    if (int(len(M_1_13_pic))) * (10 / 50) > _ >= (int(len(M_1_13_pic))) * (5 / 50) or (int(len(M_1_13_pic))) * (25 / 50) > _ >= (int(len(M_1_13_pic))) * (20 / 50) or (int(len(M_1_13_pic))) * (35 / 50) > _ >= (int(len(M_1_13_pic))) * (30 / 50):
        M_1_13_test.append(M_1_13_pic[_])
    else:
        M_1_13_train.append(M_1_13_pic[_])
# print(M_1_13_pic.shape)
M_1_13_train = np.array(M_1_13_train)
M_1_13_test = np.array(M_1_13_test)
print(M_1_13_train.shape, M_1_13_test.shape)


M_1_14_pic = []
M_1_14 = np.array(M_1_14)
M_1_14 = np.delete(M_1_14, 0, axis=1)
M_1_14 = butter_lowpass_filtfilt(M_1_14)
for j in range(int(len(M_1_14) / 4 - 4)):
    x = M_1_14[4 * j:(4 * j) + 20]
    y = x.flatten()
    y = np.insert(y, 0, float(14))
    M_1_14_pic.append(y)
M_1_14_pic = np.array(M_1_14_pic)
M_1_14_train=[]
M_1_14_test=[]
for _ in range(int(len(M_1_14_pic))):
    if (int(len(M_1_14_pic))) * (10 / 50) > _ >= (int(len(M_1_14_pic))) * (5 / 50) or (int(len(M_1_14_pic))) * (25 / 50) > _ >= (int(len(M_1_14_pic))) * (20 / 50) or (int(len(M_1_14_pic))) * (35 / 50) > _ >= (int(len(M_1_14_pic))) * (30 / 50):
        M_1_14_test.append(M_1_14_pic[_])
    else:
        M_1_14_train.append(M_1_14_pic[_])
# print(M_1_14_pic.shape)
M_1_14_train = np.array(M_1_14_train)
M_1_14_test = np.array(M_1_14_test)
print(M_1_14_train.shape, M_1_14_test.shape)


M_1_15_pic = []
M_1_15 = np.array(M_1_15)
M_1_15 = np.delete(M_1_15, 0, axis=1)
M_1_15 = butter_lowpass_filtfilt(M_1_15)
for j in range(int(len(M_1_15) / 4 - 4)):
    x = M_1_15[4 * j:(4 * j) + 20]
    y = x.flatten()
    y = np.insert(y, 0, float(15))
    M_1_15_pic.append(y)
M_1_15_pic = np.array(M_1_15_pic)
M_1_15_train=[]
M_1_15_test=[]
for _ in range(int(len(M_1_15_pic))):
    if (int(len(M_1_15_pic))) * (10 / 50) > _ >= (int(len(M_1_15_pic))) * (5 / 50) or (int(len(M_1_15_pic))) * (25 / 50) > _ >= (int(len(M_1_15_pic))) * (20 / 50) or (int(len(M_1_15_pic))) * (35 / 50) > _ >= (int(len(M_1_15_pic))) * (30 / 50):
        M_1_15_test.append(M_1_15_pic[_])
    else:
        M_1_15_train.append(M_1_15_pic[_])
# print(M_1_15_pic.shape)
M_1_15_train = np.array(M_1_15_train)
M_1_15_test = np.array(M_1_15_test)
print(M_1_15_train.shape, M_1_15_test.shape)


M_1_16_pic = []
M_1_16 = np.array(M_1_16)
M_1_16 = np.delete(M_1_16, 0, axis=1)
M_1_16 = butter_lowpass_filtfilt(M_1_16)
for j in range(int(len(M_1_16) / 4 - 4)):
    x = M_1_16[4 * j:(4 * j) + 20]
    y = x.flatten()
    y = np.insert(y, 0, float(16))
    M_1_16_pic.append(y)
M_1_16_pic = np.array(M_1_16_pic)
M_1_16_train=[]
M_1_16_test=[]
for _ in range(int(len(M_1_16_pic))):
    if (int(len(M_1_16_pic))) * (10 / 50) > _ >= (int(len(M_1_16_pic))) * (5 / 50) or (int(len(M_1_16_pic))) * (25 / 50) > _ >= (int(len(M_1_16_pic))) * (20 / 50) or (int(len(M_1_16_pic))) * (35 / 50) > _ >= (int(len(M_1_16_pic))) * (30 / 50):
        M_1_16_test.append(M_1_16_pic[_])
    else:
        M_1_16_train.append(M_1_16_pic[_])
# print(M_1_16_pic.shape)
M_1_16_train = np.array(M_1_16_train)
M_1_16_test = np.array(M_1_16_test)
print(M_1_16_train.shape, M_1_16_test.shape)


M_1_17_pic = []
M_1_17 = np.array(M_1_17)
M_1_17 = np.delete(M_1_17, 0, axis=1)
M_1_17 = butter_lowpass_filtfilt(M_1_17)
for j in range(int(len(M_1_17) / 4 - 4)):
    x = M_1_17[4 * j:(4 * j) + 20]
    y = x.flatten()
    y = np.insert(y, 0, float(17))
    M_1_17_pic.append(y)
M_1_17_pic = np.array(M_1_17_pic)
M_1_17_train=[]
M_1_17_test=[]
for _ in range(int(len(M_1_17_pic))):
    if (int(len(M_1_17_pic))) * (10 / 50) > _ >= (int(len(M_1_17_pic))) * (5 / 50) or (int(len(M_1_17_pic))) * (25 / 50) > _ >= (int(len(M_1_17_pic))) * (20 / 50) or (int(len(M_1_17_pic))) * (35 / 50) > _ >= (int(len(M_1_17_pic))) * (30 / 50):
        M_1_17_test.append(M_1_17_pic[_])
    else:
        M_1_17_train.append(M_1_17_pic[_])
# print(M_1_17_pic.shape)
M_1_17_train = np.array(M_1_17_train)
M_1_17_test = np.array(M_1_17_test)
print(M_1_17_train.shape, M_1_17_test.shape)


M_1_18_pic = []
M_1_18 = np.array(M_1_18)
M_1_18 = np.delete(M_1_18, 0, axis=1)
M_1_18 = butter_lowpass_filtfilt(M_1_18)
for j in range(int(len(M_1_18) / 4 - 4)):
    x = M_1_18[4 * j:(4 * j) + 20]
    y = x.flatten()
    y = np.insert(y, 0, float(18))
    M_1_18_pic.append(y)
M_1_18_pic = np.array(M_1_18_pic)
M_1_18_train=[]
M_1_18_test=[]
for _ in range(int(len(M_1_18_pic))):
    if (int(len(M_1_18_pic))) * (10 / 50) > _ >= (int(len(M_1_18_pic))) * (5 / 50) or (int(len(M_1_18_pic))) * (25 / 50) > _ >= (int(len(M_1_18_pic))) * (20 / 50) or (int(len(M_1_18_pic))) * (35 / 50) > _ >= (int(len(M_1_18_pic))) * (30 / 50):
        M_1_18_test.append(M_1_18_pic[_])
    else:
        M_1_18_train.append(M_1_18_pic[_])
# print(M_1_18_pic.shape)
M_1_18_train = np.array(M_1_18_train)
M_1_18_test = np.array(M_1_18_test)
print(M_1_18_train.shape, M_1_18_test.shape)


M_1_19_pic = []
M_1_19 = np.array(M_1_19)
M_1_19 = np.delete(M_1_19, 0, axis=1)
M_1_19 = butter_lowpass_filtfilt(M_1_19)
for j in range(int(len(M_1_19) / 4 - 4)):
    x = M_1_19[4 * j:(4 * j) + 20]
    y = x.flatten()
    y = np.insert(y, 0, float(19))
    M_1_19_pic.append(y)
M_1_19_pic = np.array(M_1_19_pic)
M_1_19_train=[]
M_1_19_test=[]
for _ in range(int(len(M_1_19_pic))):
    if (int(len(M_1_19_pic))) * (10 / 50) > _ >= (int(len(M_1_19_pic))) * (5 / 50) or (int(len(M_1_19_pic))) * (25 / 50) > _ >= (int(len(M_1_19_pic))) * (20 / 50) or (int(len(M_1_19_pic))) * (35 / 50) > _ >= (int(len(M_1_19_pic))) * (30 / 50):
        M_1_19_test.append(M_1_19_pic[_])
    else:
        M_1_19_train.append(M_1_19_pic[_])
# print(M_1_19_pic.shape)
M_1_19_train = np.array(M_1_19_train)
M_1_19_test = np.array(M_1_19_test)
print(M_1_19_train.shape, M_1_19_test.shape)


M_1_20_pic = []
M_1_20 = np.array(M_1_20)
M_1_20 = np.delete(M_1_20, 0, axis=1)
M_1_20 = butter_lowpass_filtfilt(M_1_20)
for j in range(int(len(M_1_20) / 4 - 4)):
    x = M_1_20[4 * j:(4 * j) + 20]
    y = x.flatten()
    y = np.insert(y, 0, float(20))
    M_1_20_pic.append(y)
M_1_20_pic = np.array(M_1_20_pic)
M_1_20_train=[]
M_1_20_test=[]
for _ in range(int(len(M_1_20_pic))):
    if (int(len(M_1_20_pic))) * (10 / 50) > _ >= (int(len(M_1_20_pic))) * (5 / 50) or (int(len(M_1_20_pic))) * (25 / 50) > _ >= (int(len(M_1_20_pic))) * (20 / 50) or (int(len(M_1_20_pic))) * (35 / 50) > _ >= (int(len(M_1_20_pic))) * (30 / 50):
        M_1_20_test.append(M_1_20_pic[_])
    else:
        M_1_20_train.append(M_1_20_pic[_])
# print(M_1_20_pic.shape)
M_1_20_train = np.array(M_1_20_train)
M_1_20_test = np.array(M_1_20_test)
print(M_1_20_train.shape, M_1_20_test.shape)


M_1_21_pic = []
M_1_21 = np.array(M_1_21)
M_1_21 = np.delete(M_1_21, 0, axis=1)
M_1_21 = butter_lowpass_filtfilt(M_1_21)
for j in range(int(len(M_1_21) / 4 - 4)):
    x = M_1_21[4 * j:(4 * j) + 20]
    y = x.flatten()
    y = np.insert(y, 0, float(21))
    M_1_21_pic.append(y)
M_1_21_pic = np.array(M_1_21_pic)
M_1_21_train=[]
M_1_21_test=[]
for _ in range(int(len(M_1_21_pic))):
    if (int(len(M_1_21_pic))) * (10 / 50) > _ >= (int(len(M_1_21_pic))) * (5 / 50) or (int(len(M_1_21_pic))) * (25 / 50) > _ >= (int(len(M_1_21_pic))) * (20 / 50) or (int(len(M_1_21_pic))) * (35 / 50) > _ >= (int(len(M_1_21_pic))) * (30 / 50):
        M_1_21_test.append(M_1_21_pic[_])
    else:
        M_1_21_train.append(M_1_21_pic[_])
# print(M_1_21_pic.shape)
M_1_21_train = np.array(M_1_21_train)
M_1_21_test = np.array(M_1_21_test)
print(M_1_21_train.shape, M_1_21_test.shape)


M_1_22_pic = []
M_1_22 = np.array(M_1_22)
M_1_22 = np.delete(M_1_22, 0, axis=1)
M_1_22 = butter_lowpass_filtfilt(M_1_22)
for j in range(int(len(M_1_22) / 4 - 4)):
    x = M_1_22[4 * j:(4 * j) + 20]
    y = x.flatten()
    y = np.insert(y, 0, float(22))
    M_1_22_pic.append(y)
M_1_22_pic = np.array(M_1_22_pic)
M_1_22_train=[]
M_1_22_test=[]
for _ in range(int(len(M_1_22_pic))):
    if (int(len(M_1_22_pic))) * (10 / 50) > _ >= (int(len(M_1_22_pic))) * (5 / 50) or (int(len(M_1_22_pic))) * (25 / 50) > _ >= (int(len(M_1_22_pic))) * (20 / 50) or (int(len(M_1_22_pic))) * (35 / 50) > _ >= (int(len(M_1_22_pic))) * (30 / 50):
        M_1_22_test.append(M_1_22_pic[_])
    else:
        M_1_22_train.append(M_1_22_pic[_])
# print(M_1_22_pic.shape)
M_1_22_train = np.array(M_1_22_train)
M_1_22_test = np.array(M_1_22_test)
print(M_1_22_train.shape, M_1_22_test.shape)


M_1_23_pic = []
M_1_23 = np.array(M_1_23)
M_1_23 = np.delete(M_1_23, 0, axis=1)
M_1_23 = butter_lowpass_filtfilt(M_1_23)
for j in range(int(len(M_1_23) / 4 - 4)):
    x = M_1_23[4 * j:(4 * j) + 20]
    y = x.flatten()
    y = np.insert(y, 0, float(23))
    M_1_23_pic.append(y)
M_1_23_pic = np.array(M_1_23_pic)
M_1_23_train=[]
M_1_23_test=[]
for _ in range(int(len(M_1_23_pic))):
    if (int(len(M_1_23_pic))) * (10 / 50) > _ >= (int(len(M_1_23_pic))) * (5 / 50) or (int(len(M_1_23_pic))) * (25 / 50) > _ >= (int(len(M_1_23_pic))) * (20 / 50) or (int(len(M_1_23_pic))) * (35 / 50) > _ >= (int(len(M_1_23_pic))) * (30 / 50):
        M_1_23_test.append(M_1_23_pic[_])
    else:
        M_1_23_train.append(M_1_23_pic[_])
# print(M_1_23_pic.shape)
M_1_23_train = np.array(M_1_23_train)
M_1_23_test = np.array(M_1_23_test)
print(M_1_23_train.shape, M_1_23_test.shape)


M_1_24_pic = []
M_1_24 = np.array(M_1_24)
M_1_24 = np.delete(M_1_24, 0, axis=1)
M_1_24 = butter_lowpass_filtfilt(M_1_24)
for j in range(int(len(M_1_24) / 4 - 4)):
    x = M_1_24[4 * j:(4 * j) + 20]
    y = x.flatten()
    y = np.insert(y, 0, float(24))
    M_1_24_pic.append(y)
M_1_24_pic = np.array(M_1_24_pic)
M_1_24_train=[]
M_1_24_test=[]
for _ in range(int(len(M_1_24_pic))):
    if (int(len(M_1_24_pic))) * (10 / 50) > _ >= (int(len(M_1_24_pic))) * (5 / 50) or (int(len(M_1_24_pic))) * (25 / 50) > _ >= (int(len(M_1_24_pic))) * (20 / 50) or (int(len(M_1_24_pic))) * (35 / 50) > _ >= (int(len(M_1_24_pic))) * (30 / 50):
        M_1_24_test.append(M_1_24_pic[_])
    else:
        M_1_24_train.append(M_1_24_pic[_])
# print(M_1_24_pic.shape)
M_1_24_train = np.array(M_1_24_train)
M_1_24_test = np.array(M_1_24_test)
print(M_1_24_train.shape, M_1_24_test.shape)


M_1_25_pic = []
M_1_25 = np.array(M_1_25)
M_1_25 = np.delete(M_1_25, 0, axis=1)
M_1_25 = butter_lowpass_filtfilt(M_1_25)
for j in range(int(len(M_1_25) / 4 - 4)):
    x = M_1_25[4 * j:(4 * j) + 20]
    y = x.flatten()
    y = np.insert(y, 0, float(25))
    M_1_25_pic.append(y)
M_1_25_pic = np.array(M_1_25_pic)
M_1_25_train=[]
M_1_25_test=[]
for _ in range(int(len(M_1_25_pic))):
    if (int(len(M_1_25_pic))) * (10 / 50) > _ >= (int(len(M_1_25_pic))) * (5 / 50) or (int(len(M_1_25_pic))) * (25 / 50) > _ >= (int(len(M_1_25_pic))) * (20 / 50) or (int(len(M_1_25_pic))) * (35 / 50) > _ >= (int(len(M_1_25_pic))) * (30 / 50):
        M_1_25_test.append(M_1_25_pic[_])
    else:
        M_1_25_train.append(M_1_25_pic[_])
# print(M_1_25_pic.shape)
M_1_25_train = np.array(M_1_25_train)
M_1_25_test = np.array(M_1_25_test)
print(M_1_25_train.shape, M_1_25_test.shape)


M_1_26_pic = []
M_1_26 = np.array(M_1_26)
M_1_26 = np.delete(M_1_26, 0, axis=1)
M_1_26 = butter_lowpass_filtfilt(M_1_26)
for j in range(int(len(M_1_26) / 4 - 4)):
    x = M_1_26[4 * j:(4 * j) + 20]
    y = x.flatten()
    y = np.insert(y, 0, float(26))
    M_1_26_pic.append(y)
M_1_26_pic = np.array(M_1_26_pic)
M_1_26_train=[]
M_1_26_test=[]
for _ in range(int(len(M_1_26_pic))):
    if (int(len(M_1_26_pic))) * (10 / 50) > _ >= (int(len(M_1_26_pic))) * (5 / 50) or (int(len(M_1_26_pic))) * (25 / 50) > _ >= (int(len(M_1_26_pic))) * (20 / 50) or (int(len(M_1_26_pic))) * (35 / 50) > _ >= (int(len(M_1_26_pic))) * (30 / 50):
        M_1_26_test.append(M_1_26_pic[_])
    else:
        M_1_26_train.append(M_1_26_pic[_])
# print(M_1_26_pic.shape)
M_1_26_train = np.array(M_1_26_train)
M_1_26_test = np.array(M_1_26_test)
print(M_1_26_train.shape, M_1_26_test.shape)


M_1_27_pic = []
M_1_27 = np.array(M_1_27)
M_1_27 = np.delete(M_1_27, 0, axis=1)
M_1_27 = butter_lowpass_filtfilt(M_1_27)
for j in range(int(len(M_1_27) / 4 - 4)):
    x = M_1_27[4 * j:(4 * j) + 20]
    y = x.flatten()
    y = np.insert(y, 0, float(27))
    M_1_27_pic.append(y)
M_1_27_pic = np.array(M_1_27_pic)
M_1_27_train=[]
M_1_27_test=[]
for _ in range(int(len(M_1_27_pic))):
    if (int(len(M_1_27_pic))) * (10 / 50) > _ >= (int(len(M_1_27_pic))) * (5 / 50) or (int(len(M_1_27_pic))) * (25 / 50) > _ >= (int(len(M_1_27_pic))) * (20 / 50) or (int(len(M_1_27_pic))) * (35 / 50) > _ >= (int(len(M_1_27_pic))) * (30 / 50):
        M_1_27_test.append(M_1_27_pic[_])
    else:
        M_1_27_train.append(M_1_27_pic[_])
# print(M_1_27_pic.shape)
M_1_27_train = np.array(M_1_27_train)
M_1_27_test = np.array(M_1_27_test)
print(M_1_27_train.shape, M_1_27_test.shape)


M_1_28_pic = []
M_1_28 = np.array(M_1_28)
M_1_28 = np.delete(M_1_28, 0, axis=1)
M_1_28 = butter_lowpass_filtfilt(M_1_28)
for j in range(int(len(M_1_28) / 4 - 4)):
    x = M_1_28[4 * j:(4 * j) + 20]
    y = x.flatten()
    y = np.insert(y, 0, float(28))
    M_1_28_pic.append(y)
M_1_28_pic = np.array(M_1_28_pic)
M_1_28_train=[]
M_1_28_test=[]
for _ in range(int(len(M_1_28_pic))):
    if (int(len(M_1_28_pic))) * (10 / 50) > _ >= (int(len(M_1_28_pic))) * (5 / 50) or (int(len(M_1_28_pic))) * (25 / 50) > _ >= (int(len(M_1_28_pic))) * (20 / 50) or (int(len(M_1_28_pic))) * (35 / 50) > _ >= (int(len(M_1_28_pic))) * (30 / 50):
        M_1_28_test.append(M_1_28_pic[_])
    else:
        M_1_28_train.append(M_1_28_pic[_])
# print(M_1_28_pic.shape)
M_1_28_train = np.array(M_1_28_train)
M_1_28_test = np.array(M_1_28_test)
print(M_1_28_train.shape, M_1_28_test.shape)


M_1_29_pic = []
M_1_29 = np.array(M_1_29)
M_1_29 = np.delete(M_1_29, 0, axis=1)
M_1_29 = butter_lowpass_filtfilt(M_1_29)
for j in range(int(len(M_1_29) / 4 - 4)):
    x = M_1_29[4 * j:(4 * j) + 20]
    y = x.flatten()
    y = np.insert(y, 0, float(29))
    M_1_29_pic.append(y)
M_1_29_pic = np.array(M_1_29_pic)
M_1_29_train=[]
M_1_29_test=[]
for _ in range(int(len(M_1_29_pic))):
    if (int(len(M_1_29_pic))) * (10 / 50) > _ >= (int(len(M_1_29_pic))) * (5 / 50) or (int(len(M_1_29_pic))) * (25 / 50) > _ >= (int(len(M_1_29_pic))) * (20 / 50) or (int(len(M_1_29_pic))) * (35 / 50) > _ >= (int(len(M_1_29_pic))) * (30 / 50):
        M_1_29_test.append(M_1_29_pic[_])
    else:
        M_1_29_train.append(M_1_29_pic[_])
# print(M_1_29_pic.shape)
M_1_29_train = np.array(M_1_29_train)
M_1_29_test = np.array(M_1_29_test)
print(M_1_29_train.shape, M_1_29_test.shape)


for i in range(len(dataset_E1_c)):
    if dataset_E1_c[i][0] != 0:
        if dataset_E1_c[i][0] == 1:
            dataset_E1_c[i][0] = 30
            M_1_30.append(dataset_E1_c[i])
        elif dataset_E1_c[i][0] == 2:
            dataset_E1_c[i][0] = 31
            M_1_31.append(dataset_E1_c[i])
        elif dataset_E1_c[i][0] == 3:
            dataset_E1_c[i][0] = 32
            M_1_32.append(dataset_E1_c[i])
        elif dataset_E1_c[i][0] == 4:
            dataset_E1_c[i][0] = 33
            M_1_33.append(dataset_E1_c[i])
        elif dataset_E1_c[i][0] == 5:
            dataset_E1_c[i][0] = 34
            M_1_34.append(dataset_E1_c[i])
        elif dataset_E1_c[i][0] == 6:
            dataset_E1_c[i][0] = 35
            M_1_35.append(dataset_E1_c[i])
        elif dataset_E1_c[i][0] == 7:
            dataset_E1_c[i][0] = 36
            M_1_36.append(dataset_E1_c[i])
        elif dataset_E1_c[i][0] == 8:
            dataset_E1_c[i][0] = 37
            M_1_37.append(dataset_E1_c[i])
        elif dataset_E1_c[i][0] == 9:
            dataset_E1_c[i][0] = 38
            M_1_38.append(dataset_E1_c[i])
        elif dataset_E1_c[i][0] == 10:
            dataset_E1_c[i][0] = 39
            M_1_39.append(dataset_E1_c[i])
        elif dataset_E1_c[i][0] == 11:
            dataset_E1_c[i][0] = 40
            M_1_40.append(dataset_E1_c[i])
        elif dataset_E1_c[i][0] == 12:
            dataset_E1_c[i][0] = 41
            M_1_41.append(dataset_E1_c[i])
        elif dataset_E1_c[i][0] == 13:
            dataset_E1_c[i][0] = 43
            M_1_42.append(dataset_E1_c[i])
        elif dataset_E1_c[i][0] == 14:
            dataset_E1_c[i][0] = 43
            M_1_43.append(dataset_E1_c[i])
        elif dataset_E1_c[i][0] == 15:
            dataset_E1_c[i][0] = 44
            M_1_44.append(dataset_E1_c[i])
        elif dataset_E1_c[i][0] == 16:
            dataset_E1_c[i][0] = 45
            M_1_45.append(dataset_E1_c[i])
        elif dataset_E1_c[i][0] == 17:
            dataset_E1_c[i][0] = 46
            M_1_46.append(dataset_E1_c[i])
        elif dataset_E1_c[i][0] == 18:
            dataset_E1_c[i][0] = 47
            M_1_47.append(dataset_E1_c[i])
        elif dataset_E1_c[i][0] == 19:
            dataset_E1_c[i][0] = 48
            M_1_48.append(dataset_E1_c[i])
        elif dataset_E1_c[i][0] == 20:
            dataset_E1_c[i][0] = 49
            M_1_49.append(dataset_E1_c[i])
        elif dataset_E1_c[i][0] == 21:
            dataset_E1_c[i][0] = 50
            M_1_50.append(dataset_E1_c[i])
        elif dataset_E1_c[i][0] == 22:
            dataset_E1_c[i][0] = 51
            M_1_51.append(dataset_E1_c[i])
        elif dataset_E1_c[i][0] == 23:
            dataset_E1_c[i][0] = 52
            M_1_52.append(dataset_E1_c[i])


M_1_30_pic = []
M_1_30 = np.array(M_1_30)
M_1_30 = np.delete(M_1_30, 0, axis=1)
M_1_30 = butter_lowpass_filtfilt(M_1_30)
for j in range(int(len(M_1_30) / 4 - 4)):
    x = M_1_30[4 * j:(4 * j) + 20]
    y = x.flatten()
    y = np.insert(y, 0, float(30))
    M_1_30_pic.append(y)
M_1_30_pic = np.array(M_1_30_pic)
M_1_30_train=[]
M_1_30_test=[]
for _ in range(int(len(M_1_30_pic))):
    if (int(len(M_1_30_pic))) * (10 / 50) > _ >= (int(len(M_1_30_pic))) * (5 / 50) or (int(len(M_1_30_pic))) * (25 / 50) > _ >= (int(len(M_1_30_pic))) * (20 / 50) or (int(len(M_1_30_pic))) * (35 / 50) > _ >= (int(len(M_1_30_pic))) * (30 / 50):
        M_1_30_test.append(M_1_30_pic[_])
    else:
        M_1_30_train.append(M_1_30_pic[_])
# print(M_1_30_pic.shape)
M_1_30_train = np.array(M_1_30_train)
M_1_30_test = np.array(M_1_30_test)
print(M_1_30_train.shape, M_1_30_test.shape)


M_1_31_pic = []
M_1_31 = np.array(M_1_31)
M_1_31 = np.delete(M_1_31, 0, axis=1)
M_1_31 = butter_lowpass_filtfilt(M_1_31)
for j in range(int(len(M_1_31) / 4 - 4)):
    x = M_1_31[4 * j:(4 * j) + 20]
    y = x.flatten()
    y = np.insert(y, 0, float(31))
    M_1_31_pic.append(y)
M_1_31_pic = np.array(M_1_31_pic)
M_1_31_train=[]
M_1_31_test=[]
for _ in range(int(len(M_1_31_pic))):
    if (int(len(M_1_31_pic))) * (10 / 50) > _ >= (int(len(M_1_31_pic))) * (5 / 50) or (int(len(M_1_31_pic))) * (25 / 50) > _ >= (int(len(M_1_31_pic))) * (20 / 50) or (int(len(M_1_31_pic))) * (35 / 50) > _ >= (int(len(M_1_31_pic))) * (30 / 50):
        M_1_31_test.append(M_1_31_pic[_])
    else:
        M_1_31_train.append(M_1_31_pic[_])
# print(M_1_31_pic.shape)
M_1_31_train = np.array(M_1_31_train)
M_1_31_test = np.array(M_1_31_test)
print(M_1_31_train.shape, M_1_31_test.shape)


M_1_32_pic = []
M_1_32 = np.array(M_1_32)
M_1_32 = np.delete(M_1_32, 0, axis=1)
M_1_32 = butter_lowpass_filtfilt(M_1_32)
for j in range(int(len(M_1_32) / 4 - 4)):
    x = M_1_32[4 * j:(4 * j) + 20]
    y = x.flatten()
    y = np.insert(y, 0, float(32))
    M_1_32_pic.append(y)
M_1_32_pic = np.array(M_1_32_pic)
M_1_32_train=[]
M_1_32_test=[]
for _ in range(int(len(M_1_32_pic))):
    if (int(len(M_1_32_pic))) * (10 / 50) > _ >= (int(len(M_1_32_pic))) * (5 / 50) or (int(len(M_1_32_pic))) * (25 / 50) > _ >= (int(len(M_1_32_pic))) * (20 / 50) or (int(len(M_1_32_pic))) * (35 / 50) > _ >= (int(len(M_1_32_pic))) * (30 / 50):
        M_1_32_test.append(M_1_32_pic[_])
    else:
        M_1_32_train.append(M_1_32_pic[_])
# print(M_1_32_pic.shape)
M_1_32_train = np.array(M_1_32_train)
M_1_32_test = np.array(M_1_32_test)
print(M_1_32_train.shape, M_1_32_test.shape)


M_1_33_pic = []
M_1_33 = np.array(M_1_33)
M_1_33 = np.delete(M_1_33, 0, axis=1)
M_1_33 = butter_lowpass_filtfilt(M_1_33)
for j in range(int(len(M_1_33) / 4 - 4)):
    x = M_1_33[4 * j:(4 * j) + 20]
    y = x.flatten()
    y = np.insert(y, 0, float(33))
    M_1_33_pic.append(y)
M_1_33_pic = np.array(M_1_33_pic)
M_1_33_train=[]
M_1_33_test=[]
for _ in range(int(len(M_1_33_pic))):
    if (int(len(M_1_33_pic))) * (10 / 50) > _ >= (int(len(M_1_33_pic))) * (5 / 50) or (int(len(M_1_33_pic))) * (25 / 50) > _ >= (int(len(M_1_33_pic))) * (20 / 50) or (int(len(M_1_33_pic))) * (35 / 50) > _ >= (int(len(M_1_33_pic))) * (30 / 50):
        M_1_33_test.append(M_1_33_pic[_])
    else:
        M_1_33_train.append(M_1_33_pic[_])
# print(M_1_33_pic.shape)
M_1_33_train = np.array(M_1_33_train)
M_1_33_test = np.array(M_1_33_test)
print(M_1_33_train.shape, M_1_33_test.shape)


M_1_34_pic = []
M_1_34 = np.array(M_1_34)
M_1_34 = np.delete(M_1_34, 0, axis=1)
M_1_34 = butter_lowpass_filtfilt(M_1_34)
for j in range(int(len(M_1_34) / 4 - 4)):
    x = M_1_34[4 * j:(4 * j) + 20]
    y = x.flatten()
    y = np.insert(y, 0, float(34))
    M_1_34_pic.append(y)
M_1_34_pic = np.array(M_1_34_pic)
M_1_34_train=[]
M_1_34_test=[]
for _ in range(int(len(M_1_34_pic))):
    if (int(len(M_1_34_pic))) * (10 / 50) > _ >= (int(len(M_1_34_pic))) * (5 / 50) or (int(len(M_1_34_pic))) * (25 / 50) > _ >= (int(len(M_1_34_pic))) * (20 / 50) or (int(len(M_1_34_pic))) * (35 / 50) > _ >= (int(len(M_1_34_pic))) * (30 / 50):
        M_1_34_test.append(M_1_34_pic[_])
    else:
        M_1_34_train.append(M_1_34_pic[_])
# print(M_1_34_pic.shape)
M_1_34_train = np.array(M_1_34_train)
M_1_34_test = np.array(M_1_34_test)
print(M_1_34_train.shape, M_1_34_test.shape)


M_1_35_pic = []
M_1_35 = np.array(M_1_35)
M_1_35 = np.delete(M_1_35, 0, axis=1)
M_1_35 = butter_lowpass_filtfilt(M_1_35)
for j in range(int(len(M_1_35) / 4 - 4)):
    x = M_1_35[4 * j:(4 * j) + 20]
    y = x.flatten()
    y = np.insert(y, 0, float(35))
    M_1_35_pic.append(y)
M_1_35_pic = np.array(M_1_35_pic)
M_1_35_train=[]
M_1_35_test=[]
for _ in range(int(len(M_1_35_pic))):
    if (int(len(M_1_35_pic))) * (10 / 50) > _ >= (int(len(M_1_35_pic))) * (5 / 50) or (int(len(M_1_35_pic))) * (25 / 50) > _ >= (int(len(M_1_35_pic))) * (20 / 50) or (int(len(M_1_35_pic))) * (35 / 50) > _ >= (int(len(M_1_35_pic))) * (30 / 50):
        M_1_35_test.append(M_1_35_pic[_])
    else:
        M_1_35_train.append(M_1_35_pic[_])
# print(M_1_35_pic.shape)
M_1_35_train = np.array(M_1_35_train)
M_1_35_test = np.array(M_1_35_test)
print(M_1_35_train.shape, M_1_35_test.shape)


M_1_36_pic = []
M_1_36 = np.array(M_1_36)
M_1_36 = np.delete(M_1_36, 0, axis=1)
M_1_36 = butter_lowpass_filtfilt(M_1_36)
for j in range(int(len(M_1_36) / 4 - 4)):
    x = M_1_36[4 * j:(4 * j) + 20]
    y = x.flatten()
    y = np.insert(y, 0, float(36))
    M_1_36_pic.append(y)
M_1_36_pic = np.array(M_1_36_pic)
M_1_36_train=[]
M_1_36_test=[]
for _ in range(int(len(M_1_36_pic))):
    if (int(len(M_1_36_pic))) * (10 / 50) > _ >= (int(len(M_1_36_pic))) * (5 / 50) or (int(len(M_1_36_pic))) * (25 / 50) > _ >= (int(len(M_1_36_pic))) * (20 / 50) or (int(len(M_1_36_pic))) * (35 / 50) > _ >= (int(len(M_1_36_pic))) * (30 / 50):
        M_1_36_test.append(M_1_36_pic[_])
    else:
        M_1_36_train.append(M_1_36_pic[_])
# print(M_1_36_pic.shape)
M_1_36_train = np.array(M_1_36_train)
M_1_36_test = np.array(M_1_36_test)
print(M_1_36_train.shape, M_1_36_test.shape)


M_1_37_pic = []
M_1_37 = np.array(M_1_37)
M_1_37 = np.delete(M_1_37, 0, axis=1)
M_1_37 = butter_lowpass_filtfilt(M_1_37)
for j in range(int(len(M_1_37) / 4 - 4)):
    x = M_1_37[4 * j:(4 * j) + 20]
    y = x.flatten()
    y = np.insert(y, 0, float(37))
    M_1_37_pic.append(y)
M_1_37_pic = np.array(M_1_37_pic)
M_1_37_train=[]
M_1_37_test=[]
for _ in range(int(len(M_1_37_pic))):
    if (int(len(M_1_37_pic))) * (10 / 50) > _ >= (int(len(M_1_37_pic))) * (5 / 50) or (int(len(M_1_37_pic))) * (25 / 50) > _ >= (int(len(M_1_37_pic))) * (20 / 50) or (int(len(M_1_37_pic))) * (35 / 50) > _ >= (int(len(M_1_37_pic))) * (30 / 50):
        M_1_37_test.append(M_1_37_pic[_])
    else:
        M_1_37_train.append(M_1_37_pic[_])
# print(M_1_37_pic.shape)
M_1_37_train = np.array(M_1_37_train)
M_1_37_test = np.array(M_1_37_test)
print(M_1_37_train.shape, M_1_37_test.shape)


M_1_38_pic = []
M_1_38 = np.array(M_1_38)
M_1_38 = np.delete(M_1_38, 0, axis=1)
M_1_38 = butter_lowpass_filtfilt(M_1_38)
for j in range(int(len(M_1_38) / 4 - 4)):
    x = M_1_38[4 * j:(4 * j) + 20]
    y = x.flatten()
    y = np.insert(y, 0, float(38))
    M_1_38_pic.append(y)
M_1_38_pic = np.array(M_1_38_pic)
M_1_38_train=[]
M_1_38_test=[]
for _ in range(int(len(M_1_38_pic))):
    if (int(len(M_1_38_pic))) * (10 / 50) > _ >= (int(len(M_1_38_pic))) * (5 / 50) or (int(len(M_1_38_pic))) * (25 / 50) > _ >= (int(len(M_1_38_pic))) * (20 / 50) or (int(len(M_1_38_pic))) * (35 / 50) > _ >= (int(len(M_1_38_pic))) * (30 / 50):
        M_1_38_test.append(M_1_38_pic[_])
    else:
        M_1_38_train.append(M_1_38_pic[_])
# print(M_1_38_pic.shape)
M_1_38_train = np.array(M_1_38_train)
M_1_38_test = np.array(M_1_38_test)
print(M_1_38_train.shape, M_1_38_test.shape)


M_1_39_pic = []
M_1_39 = np.array(M_1_39)
M_1_39 = np.delete(M_1_39, 0, axis=1)
M_1_39 = butter_lowpass_filtfilt(M_1_39)
for j in range(int(len(M_1_39) / 4 - 4)):
    x = M_1_39[4 * j:(4 * j) + 20]
    y = x.flatten()
    y = np.insert(y, 0, float(39))
    M_1_39_pic.append(y)
M_1_39_pic = np.array(M_1_39_pic)
M_1_39_train=[]
M_1_39_test=[]
for _ in range(int(len(M_1_39_pic))):
    if (int(len(M_1_39_pic))) * (10 / 50) > _ >= (int(len(M_1_39_pic))) * (5 / 50) or (int(len(M_1_39_pic))) * (25 / 50) > _ >= (int(len(M_1_39_pic))) * (20 / 50) or (int(len(M_1_39_pic))) * (35 / 50) > _ >= (int(len(M_1_39_pic))) * (30 / 50):
        M_1_39_test.append(M_1_39_pic[_])
    else:
        M_1_39_train.append(M_1_39_pic[_])
# print(M_1_39_pic.shape)
M_1_39_train = np.array(M_1_39_train)
M_1_39_test = np.array(M_1_39_test)
print(M_1_39_train.shape, M_1_39_test.shape)


M_1_40_pic = []
M_1_40 = np.array(M_1_40)
M_1_40 = np.delete(M_1_40, 0, axis=1)
M_1_40 = butter_lowpass_filtfilt(M_1_40)
for j in range(int(len(M_1_40) / 4 - 4)):
    x = M_1_40[4 * j:(4 * j) + 20]
    y = x.flatten()
    y = np.insert(y, 0, float(40))
    M_1_40_pic.append(y)
M_1_40_pic = np.array(M_1_40_pic)
M_1_40_train=[]
M_1_40_test=[]
for _ in range(int(len(M_1_40_pic))):
    if (int(len(M_1_40_pic))) * (10 / 50) > _ >= (int(len(M_1_40_pic))) * (5 / 50) or (int(len(M_1_40_pic))) * (25 / 50) > _ >= (int(len(M_1_40_pic))) * (20 / 50) or (int(len(M_1_40_pic))) * (35 / 50) > _ >= (int(len(M_1_40_pic))) * (30 / 50):
        M_1_40_test.append(M_1_40_pic[_])
    else:
        M_1_40_train.append(M_1_40_pic[_])
# print(M_1_40_pic.shape)
M_1_40_train = np.array(M_1_40_train)
M_1_40_test = np.array(M_1_40_test)
print(M_1_40_train.shape, M_1_40_test.shape)


M_1_41_pic = []
M_1_41 = np.array(M_1_41)
M_1_41 = np.delete(M_1_41, 0, axis=1)
M_1_41 = butter_lowpass_filtfilt(M_1_41)
for j in range(int(len(M_1_41) / 4 - 4)):
    x = M_1_41[4 * j:(4 * j) + 20]
    y = x.flatten()
    y = np.insert(y, 0, float(41))
    M_1_41_pic.append(y)
M_1_41_pic = np.array(M_1_41_pic)
M_1_41_train=[]
M_1_41_test=[]
for _ in range(int(len(M_1_41_pic))):
    if (int(len(M_1_41_pic))) * (10 / 50) > _ >= (int(len(M_1_41_pic))) * (5 / 50) or (int(len(M_1_41_pic))) * (25 / 50) > _ >= (int(len(M_1_41_pic))) * (20 / 50) or (int(len(M_1_41_pic))) * (35 / 50) > _ >= (int(len(M_1_41_pic))) * (30 / 50):
        M_1_41_test.append(M_1_41_pic[_])
    else:
        M_1_41_train.append(M_1_41_pic[_])
# print(M_1_41_pic.shape)
M_1_41_train = np.array(M_1_41_train)
M_1_41_test = np.array(M_1_41_test)
print(M_1_41_train.shape, M_1_41_test.shape)

M_1_42_pic = []
M_1_42 = np.array(M_1_42)
M_1_42 = np.delete(M_1_42, 0, axis=1)
M_1_42 = butter_lowpass_filtfilt(M_1_42)
for j in range(int(len(M_1_42) / 4 - 4)):
    x = M_1_42[4 * j:(4 * j) + 20]
    y = x.flatten()
    y = np.insert(y, 0, float(42))
    M_1_42_pic.append(y)
M_1_42_pic = np.array(M_1_42_pic)
M_1_42_train=[]
M_1_42_test=[]
for _ in range(int(len(M_1_42_pic))):
    if (int(len(M_1_42_pic))) * (10 / 50) > _ >= (int(len(M_1_42_pic))) * (5 / 50) or (int(len(M_1_42_pic))) * (25 / 50) > _ >= (int(len(M_1_42_pic))) * (20 / 50) or (int(len(M_1_42_pic))) * (35 / 50) > _ >= (int(len(M_1_42_pic))) * (30 / 50):
        M_1_42_test.append(M_1_42_pic[_])
    else:
        M_1_42_train.append(M_1_42_pic[_])
# print(M_1_42_pic.shape)
M_1_42_train = np.array(M_1_42_train)
M_1_42_test = np.array(M_1_42_test)
print(M_1_42_train.shape, M_1_42_test.shape)


M_1_43_pic = []
M_1_43 = np.array(M_1_43)
M_1_43 = np.delete(M_1_43, 0, axis=1)
M_1_43 = butter_lowpass_filtfilt(M_1_43)
for j in range(int(len(M_1_43) / 4 - 4)):
    x = M_1_43[4 * j:(4 * j) + 20]
    y = x.flatten()
    y = np.insert(y, 0, float(43))
    M_1_43_pic.append(y)
M_1_43_pic = np.array(M_1_43_pic)
M_1_43_train=[]
M_1_43_test=[]
for _ in range(int(len(M_1_43_pic))):
    if (int(len(M_1_43_pic))) * (10 / 50) > _ >= (int(len(M_1_43_pic))) * (5 / 50) or (int(len(M_1_43_pic))) * (25 / 50) > _ >= (int(len(M_1_43_pic))) * (20 / 50) or (int(len(M_1_43_pic))) * (35 / 50) > _ >= (int(len(M_1_43_pic))) * (30 / 50):
        M_1_43_test.append(M_1_43_pic[_])
    else:
        M_1_43_train.append(M_1_43_pic[_])
# print(M_1_43_pic.shape)
M_1_43_train = np.array(M_1_43_train)
M_1_43_test = np.array(M_1_43_test)
print(M_1_43_train.shape, M_1_43_test.shape)


M_1_44_pic = []
M_1_44 = np.array(M_1_44)
M_1_44 = np.delete(M_1_44, 0, axis=1)
M_1_44 = butter_lowpass_filtfilt(M_1_44)
for j in range(int(len(M_1_44) / 4 - 4)):
    x = M_1_44[4 * j:(4 * j) + 20]
    y = x.flatten()
    y = np.insert(y, 0, float(44))
    M_1_44_pic.append(y)
M_1_44_pic = np.array(M_1_44_pic)
M_1_44_train=[]
M_1_44_test=[]
for _ in range(int(len(M_1_44_pic))):
    if (int(len(M_1_44_pic))) * (10 / 50) > _ >= (int(len(M_1_44_pic))) * (5 / 50) or (int(len(M_1_44_pic))) * (25 / 50) > _ >= (int(len(M_1_44_pic))) * (20 / 50) or (int(len(M_1_44_pic))) * (35 / 50) > _ >= (int(len(M_1_44_pic))) * (30 / 50):
        M_1_44_test.append(M_1_44_pic[_])
    else:
        M_1_44_train.append(M_1_44_pic[_])
# print(M_1_44_pic.shape)
M_1_44_train = np.array(M_1_44_train)
M_1_44_test = np.array(M_1_44_test)
print(M_1_44_train.shape, M_1_44_test.shape)


M_1_45_pic = []
M_1_45 = np.array(M_1_45)
M_1_45 = np.delete(M_1_45, 0, axis=1)
M_1_45 = butter_lowpass_filtfilt(M_1_45)
for j in range(int(len(M_1_45) / 4 - 4)):
    x = M_1_45[4 * j:(4 * j) + 20]
    y = x.flatten()
    y = np.insert(y, 0, float(45))
    M_1_45_pic.append(y)
M_1_45_pic = np.array(M_1_45_pic)
M_1_45_train=[]
M_1_45_test=[]
for _ in range(int(len(M_1_45_pic))):
    if (int(len(M_1_45_pic))) * (10 / 50) > _ >= (int(len(M_1_45_pic))) * (5 / 50) or (int(len(M_1_45_pic))) * (25 / 50) > _ >= (int(len(M_1_45_pic))) * (20 / 50) or (int(len(M_1_45_pic))) * (35 / 50) > _ >= (int(len(M_1_45_pic))) * (30 / 50):
        M_1_45_test.append(M_1_45_pic[_])
    else:
        M_1_45_train.append(M_1_45_pic[_])
# print(M_1_45_pic.shape)
M_1_45_train = np.array(M_1_45_train)
M_1_45_test = np.array(M_1_45_test)
print(M_1_45_train.shape, M_1_45_test.shape)


M_1_46_pic = []
M_1_46 = np.array(M_1_46)
M_1_46 = np.delete(M_1_46, 0, axis=1)
M_1_46 = butter_lowpass_filtfilt(M_1_46)
for j in range(int(len(M_1_46) / 4 - 4)):
    x = M_1_46[4 * j:(4 * j) + 20]
    y = x.flatten()
    y = np.insert(y, 0, float(46))
    M_1_46_pic.append(y)
M_1_46_pic = np.array(M_1_46_pic)
M_1_46_train=[]
M_1_46_test=[]
for _ in range(int(len(M_1_46_pic))):
    if (int(len(M_1_46_pic))) * (10 / 50) > _ >= (int(len(M_1_46_pic))) * (5 / 50) or (int(len(M_1_46_pic))) * (25 / 50) > _ >= (int(len(M_1_46_pic))) * (20 / 50) or (int(len(M_1_46_pic))) * (35 / 50) > _ >= (int(len(M_1_46_pic))) * (30 / 50):
        M_1_46_test.append(M_1_46_pic[_])
    else:
        M_1_46_train.append(M_1_46_pic[_])
# print(M_1_46_pic.shape)
M_1_46_train = np.array(M_1_46_train)
M_1_46_test = np.array(M_1_46_test)
print(M_1_46_train.shape, M_1_46_test.shape)


M_1_47_pic = []
M_1_47 = np.array(M_1_47)
M_1_47 = np.delete(M_1_47, 0, axis=1)
M_1_47 = butter_lowpass_filtfilt(M_1_47)
for j in range(int(len(M_1_47) / 4 - 4)):
    x = M_1_47[4 * j:(4 * j) + 20]
    y = x.flatten()
    y = np.insert(y, 0, float(47))
    M_1_47_pic.append(y)
M_1_47_pic = np.array(M_1_47_pic)
M_1_47_train=[]
M_1_47_test=[]
for _ in range(int(len(M_1_47_pic))):
    if (int(len(M_1_47_pic))) * (10 / 50) > _ >= (int(len(M_1_47_pic))) * (5 / 50) or (int(len(M_1_47_pic))) * (25 / 50) > _ >= (int(len(M_1_47_pic))) * (20 / 50) or (int(len(M_1_47_pic))) * (35 / 50) > _ >= (int(len(M_1_47_pic))) * (30 / 50):
        M_1_47_test.append(M_1_47_pic[_])
    else:
        M_1_47_train.append(M_1_47_pic[_])
# print(M_1_47_pic.shape)
M_1_47_train = np.array(M_1_47_train)
M_1_47_test = np.array(M_1_47_test)
print(M_1_47_train.shape, M_1_47_test.shape)


M_1_48_pic = []
M_1_48 = np.array(M_1_48)
M_1_48 = np.delete(M_1_48, 0, axis=1)
M_1_48 = butter_lowpass_filtfilt(M_1_48)
for j in range(int(len(M_1_48) / 4 - 4)):
    x = M_1_48[4 * j:(4 * j) + 20]
    y = x.flatten()
    y = np.insert(y, 0, float(48))
    M_1_48_pic.append(y)
M_1_48_pic = np.array(M_1_48_pic)
M_1_48_train=[]
M_1_48_test=[]
for _ in range(int(len(M_1_48_pic))):
    if (int(len(M_1_48_pic))) * (10 / 50) > _ >= (int(len(M_1_48_pic))) * (5 / 50) or (int(len(M_1_48_pic))) * (25 / 50) > _ >= (int(len(M_1_48_pic))) * (20 / 50) or (int(len(M_1_48_pic))) * (35 / 50) > _ >= (int(len(M_1_48_pic))) * (30 / 50):
        M_1_48_test.append(M_1_48_pic[_])
    else:
        M_1_48_train.append(M_1_48_pic[_])
# print(M_1_48_pic.shape)
M_1_48_train = np.array(M_1_48_train)
M_1_48_test = np.array(M_1_48_test)
print(M_1_48_train.shape, M_1_48_test.shape)


M_1_49_pic = []
M_1_49 = np.array(M_1_49)
M_1_49 = np.delete(M_1_49, 0, axis=1)
M_1_49 = butter_lowpass_filtfilt(M_1_49)
for j in range(int(len(M_1_49) / 4 - 4)):
    x = M_1_49[4 * j:(4 * j) + 20]
    y = x.flatten()
    y = np.insert(y, 0, float(49))
    M_1_49_pic.append(y)
M_1_49_pic = np.array(M_1_49_pic)
M_1_49_train=[]
M_1_49_test=[]
for _ in range(int(len(M_1_49_pic))):
    if (int(len(M_1_49_pic))) * (10 / 50) > _ >= (int(len(M_1_49_pic))) * (5 / 50) or (int(len(M_1_49_pic))) * (25 / 50) > _ >= (int(len(M_1_49_pic))) * (20 / 50) or (int(len(M_1_49_pic))) * (35 / 50) > _ >= (int(len(M_1_49_pic))) * (30 / 50):
        M_1_49_test.append(M_1_49_pic[_])
    else:
        M_1_49_train.append(M_1_49_pic[_])
# print(M_1_49_pic.shape)
M_1_49_train = np.array(M_1_49_train)
M_1_49_test = np.array(M_1_49_test)
print(M_1_49_train.shape, M_1_49_test.shape)


M_1_50_pic = []
M_1_50 = np.array(M_1_50)
M_1_50 = np.delete(M_1_50, 0, axis=1)
M_1_50 = butter_lowpass_filtfilt(M_1_50)
for j in range(int(len(M_1_50) / 4 - 4)):
    x = M_1_50[4 * j:(4 * j) + 20]
    y = x.flatten()
    y = np.insert(y, 0, float(50))
    M_1_50_pic.append(y)
M_1_50_pic = np.array(M_1_50_pic)
M_1_50_train=[]
M_1_50_test=[]
for _ in range(int(len(M_1_50_pic))):
    if (int(len(M_1_50_pic))) * (10 / 50) > _ >= (int(len(M_1_50_pic))) * (5 / 50) or (int(len(M_1_50_pic))) * (25 / 50) > _ >= (int(len(M_1_50_pic))) * (20 / 50) or (int(len(M_1_50_pic))) * (35 / 50) > _ >= (int(len(M_1_50_pic))) * (30 / 50):
        M_1_50_test.append(M_1_50_pic[_])
    else:
        M_1_50_train.append(M_1_50_pic[_])
# print(M_1_50_pic.shape)
M_1_50_train = np.array(M_1_50_train)
M_1_50_test = np.array(M_1_50_test)
print(M_1_50_train.shape, M_1_50_test.shape)


M_1_51_pic = []
M_1_51 = np.array(M_1_51)
M_1_51 = np.delete(M_1_51, 0, axis=1)
M_1_51 = butter_lowpass_filtfilt(M_1_51)
for j in range(int(len(M_1_51) / 4 - 4)):
    x = M_1_51[4 * j:(4 * j) + 20]
    y = x.flatten()
    y = np.insert(y, 0, float(51))
    M_1_51_pic.append(y)
M_1_51_pic = np.array(M_1_51_pic)
M_1_51_train=[]
M_1_51_test=[]
for _ in range(int(len(M_1_51_pic))):
    if (int(len(M_1_51_pic))) * (10 / 50) > _ >= (int(len(M_1_51_pic))) * (5 / 50) or (int(len(M_1_51_pic))) * (25 / 50) > _ >= (int(len(M_1_51_pic))) * (20 / 50) or (int(len(M_1_51_pic))) * (35 / 50) > _ >= (int(len(M_1_51_pic))) * (30 / 50):
        M_1_51_test.append(M_1_51_pic[_])
    else:
        M_1_51_train.append(M_1_51_pic[_])
# print(M_1_51_pic.shape)
M_1_51_train = np.array(M_1_51_train)
M_1_51_test = np.array(M_1_51_test)
print(M_1_51_train.shape, M_1_51_test.shape)


M_1_52_pic = []
M_1_52 = np.array(M_1_52)
M_1_52 = np.delete(M_1_52, 0, axis=1)
M_1_52 = butter_lowpass_filtfilt(M_1_52)
for j in range(int(len(M_1_52) / 4 - 4)):
    x = M_1_52[4 * j:(4*j) + 20]
    y = x.flatten()
    y = np.insert(y, 0, float(52))
    M_1_52_pic.append(y)
M_1_52_pic = np.array(M_1_52_pic)
M_1_52_train=[]
M_1_52_test=[]
for _ in range(int(len(M_1_52_pic))):
    if (int(len(M_1_52_pic))) * (10 / 50) > _ >= (int(len(M_1_52_pic))) * (5 / 50) or (int(len(M_1_52_pic))) * (25 / 50) > _ >= (int(len(M_1_52_pic))) * (20 / 50) or (int(len(M_1_52_pic))) * (35 / 50) > _ >= (int(len(M_1_52_pic))) * (30 / 50):
        M_1_52_test.append(M_1_52_pic[_])
    else:
        M_1_52_train.append(M_1_52_pic[_])
# print(M_1_52_pic.shape)
M_1_52_train = np.array(M_1_52_train)
M_1_52_test = np.array(M_1_52_test)
print(M_1_52_train.shape, M_1_52_test.shape)



E1_train = np.vstack((M_1_1_train, M_1_2_train, M_1_3_train, M_1_4_train, M_1_5_train, M_1_6_train, M_1_7_train,
                      M_1_8_train, M_1_9_train, M_1_10_train, M_1_11_train, M_1_12_train, M_1_13_train, M_1_14_train,
                      M_1_15_train, M_1_16_train, M_1_17_train, M_1_18_train, M_1_19_train, M_1_20_train, M_1_21_train,
                      M_1_22_train, M_1_23_train, M_1_24_train, M_1_25_train, M_1_26_train, M_1_27_train, M_1_28_train,
                      M_1_29_train, M_1_30_train, M_1_31_train, M_1_32_train, M_1_33_train, M_1_34_train, M_1_35_train,
                      M_1_36_train, M_1_37_train, M_1_38_train, M_1_39_train, M_1_40_train, M_1_41_train, M_1_42_train,
                      M_1_43_train, M_1_44_train, M_1_45_train, M_1_46_train, M_1_47_train, M_1_48_train, M_1_49_train,
                      M_1_50_train, M_1_51_train, M_1_52_train))
E1_test = np.vstack((M_1_1_test, M_1_2_test, M_1_3_test, M_1_4_test, M_1_5_test, M_1_6_test, M_1_7_test,
                      M_1_8_test, M_1_9_test, M_1_10_test, M_1_11_test, M_1_12_test, M_1_17_test, M_1_14_test,
                      M_1_15_test, M_1_16_test, M_1_17_test, M_1_18_test, M_1_19_test, M_1_20_test, M_1_21_test,
                      M_1_22_test, M_1_23_test, M_1_24_test, M_1_25_test, M_1_26_test, M_1_27_test, M_1_28_test,
                      M_1_29_test, M_1_30_test, M_1_31_test, M_1_32_test, M_1_33_test, M_1_34_test, M_1_35_test,
                      M_1_36_test, M_1_37_test, M_1_38_test, M_1_39_test, M_1_40_test, M_1_41_test, M_1_42_test,
                      M_1_43_test, M_1_44_test, M_1_45_test, M_1_46_test, M_1_47_test, M_1_48_test, M_1_49_test,
                      M_1_50_test, M_1_51_test, M_1_52_test))

print(E1_train.shape, E1_test.shape)


with h5py.File('NINAPRO_1_E3.h5', 'w') as f:
    # dt = h5py.special_dtype(vlen=np.dtype('float64'))  # this is fine
    # E1_train = E1_train.flatten()
    # E1_test = E1_test.flatten()

    Data = f.create_group('E3')

    Data.create_dataset('E3_train', data=E1_train)
    Data.create_dataset('E3_test', data=E1_test)

f.close()

Database = h5py.File('NINAPRO_1_E3.h5', 'r')

Data = Database['E3']
train = Data['E3_train']
test = Data['E3_test']
print(train.shape, test.shape)

